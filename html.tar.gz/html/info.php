<?php
phpinfo();
phpversion();

?>
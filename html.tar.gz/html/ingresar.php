<?php
require_once ('conexion_lvisitas.php');
//print_r($_POST);
$instan = new Trabajo();
$instan->add_visitas($_POST['nom'], $_POST['texto']);
?>
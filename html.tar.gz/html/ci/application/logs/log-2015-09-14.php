<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:22:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:23:34 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:24:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:24:08 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:24:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:25:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:25:54 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:28:54 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 192
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 193
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:46:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 194
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 215
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 217
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 219
ERROR - 2015-09-14 10:48:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 219
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 226
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 228
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 234
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 238
ERROR - 2015-09-14 10:48:34 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-14 10:53:21 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 157 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 376
ERROR - 2015-09-14 10:53:21 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 157 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 376
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 709
ERROR - 2015-09-14 10:53:21 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 709
ERROR - 2015-09-14 10:54:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-14 10:56:12 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:56:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:56:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:59:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 10:59:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 10:59:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:01:12 --> Severity: Parsing Error --> syntax error, unexpected ']' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 533
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:01:23 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:04:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:06:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:07:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:07:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:07:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:07:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:07:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:12:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:15:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:15:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 586
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 586
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 586
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 586
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:21:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:21:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:21:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:21:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:21:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:24:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:24:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:24:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:24:10 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:24:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:24:10 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:24:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:29:35 --> Severity: Error --> Call to undefined method B_up_xml_controller1::compara_cambia_estructura() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-14 11:30:21 --> Severity: Error --> Call to undefined method B_up_xml_controller1::compara_cambia_estructura() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 133
ERROR - 2015-09-14 11:32:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:32:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:32:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:32:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:32:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:33:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 11:33:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:33:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:33:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:33:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:33:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:33:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:35:05 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/views/b_xmlcaso2_view.php 184
ERROR - 2015-09-14 11:35:36 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:35:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:35:36 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:35:36 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:35:36 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:35:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:35:36 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:35:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:37:19 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:37:19 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:37:19 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:37:19 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:37:19 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 330
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 343
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 349
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:38:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 330
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 343
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 349
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:39:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 330
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 332
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 343
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 349
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 355
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:40:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:41:18 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:49:06 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:50:32 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:50:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:50:52 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:52:09 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-14 11:52:09 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-14 11:52:09 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-14 11:52:09 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 150
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:55:48 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:55:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 11:58:46 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 11:59:43 --> Severity: Parsing Error --> syntax error, unexpected '[' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:17 --> Severity: Parsing Error --> syntax error, unexpected ''id_uuid'' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:00:38 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting '(' /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 25
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 37
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 49
ERROR - 2015-09-14 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 49
ERROR - 2015-09-14 12:02:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 57
ERROR - 2015-09-14 12:02:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 57
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:04:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:04:45 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/b_xmlcaso2_view.php 17
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 26
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 38
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-14 12:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-14 12:05:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-14 12:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: a /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 26
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 38
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-14 12:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-14 12:06:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-14 12:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: a /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:11:09 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 28
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 40
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 52
ERROR - 2015-09-14 12:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 52
ERROR - 2015-09-14 12:12:11 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 60
ERROR - 2015-09-14 12:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 60
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:13:25 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:16:11 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: key /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:18:25 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:19:24 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:21:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:21:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:21:11 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:21:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 10
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:21:57 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:21:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:22:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:22:26 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:22:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:22:57 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:22:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:22:57 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:22:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:24:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:24:31 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Use of undefined constant cont - assumed 'cont' /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:24:31 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 62
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:28 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:26:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:26:39 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:26:39 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:28:26 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:28:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:28:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:28:26 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:28:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:35 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:29:35 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:29:58 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:29:58 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:31:38 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 29
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 41
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 53
ERROR - 2015-09-14 12:31:38 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 61
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:33:57 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:33:57 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:40:07 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 9
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:40:07 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:42:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:42:23 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:48:17 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 15
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:48:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:48:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:48:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:56:08 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-14 12:56:08 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:56:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-14 12:58:47 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 12:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 12:58:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 12:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:00:31 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso2_view.php 25
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/b_xmlcaso2_view.php 25
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:00:31 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:00:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:01:15 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:01:15 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:02:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:02:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:02:23 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:02:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:04:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:04:03 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:04:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:04:27 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 34
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 46
ERROR - 2015-09-14 13:06:22 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 54
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:08:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:08:06 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:04 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:09:20 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:10:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:10:42 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:30 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:11:52 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:03 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:13:31 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:14:26 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:14:45 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 22
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:15:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-14 13:15:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:15:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:16:41 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:17:00 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:17:00 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 13:17:00 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:17:00 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:17:00 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:17:51 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:18:20 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:19:05 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:23:27 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:23:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:23:27 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:23:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:26:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:26:13 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:26:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:27:50 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: contador /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:28:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:28:17 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:28:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:29:24 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:32:25 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:34:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: arr /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/views/b_xmlcaso2_view.php 32
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-14 13:36:51 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 63
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 44
ERROR - 2015-09-14 13:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 44
ERROR - 2015-09-14 13:44:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 52
ERROR - 2015-09-14 13:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 52
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:51:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:54:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:55:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:56:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:10 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:58:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 13:59:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:00:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:03:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 334
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:39 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:04:53 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 195
ERROR - 2015-09-14 14:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 195
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:05:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:05:51 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 184
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 184
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:06:36 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 210
ERROR - 2015-09-14 14:31:02 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:31:02 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:31:02 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:32:48 --> Severity: Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-14 14:34:40 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:34:40 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:34:40 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:43:05 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:43:05 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:43:05 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:49:02 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:49:02 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:49:02 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:50:55 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:50:55 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:50:55 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:51:33 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:51:33 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:51:33 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 14:53:32 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 14:53:32 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 14:53:32 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:06:57 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:06:57 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:06:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:09:58 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:09:58 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:09:58 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:15:27 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:15:27 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:15:27 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:22:17 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:22:17 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:22:17 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:23:02 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:23:02 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:23:02 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:23:56 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:23:56 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:23:56 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:26:07 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:26:07 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:26:07 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:29:44 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:29:44 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:29:44 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:30:35 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:30:35 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:30:35 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:31:47 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:31:47 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:31:47 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:33:28 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:33:28 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:33:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:33:55 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:33:55 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:33:55 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:35:21 --> Severity: Notice --> Undefined variable: d_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 15:35:21 --> Severity: Notice --> Undefined variable: datos_in_numserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-14 15:35:21 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 15:42:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:46:35 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 15:46:35 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 15:46:35 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:46:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:47:51 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 15:47:51 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 15:47:51 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:47:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:47:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 15:49:28 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 15:49:28 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 15:49:28 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:49:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 15:49:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 15:50:33 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 15:54:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-14 16:00:17 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/controllers/B_up_xml_controller1.php 680
ERROR - 2015-09-14 16:00:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:00:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 16:00:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 16:00:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 690
ERROR - 2015-09-14 16:04:25 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 680
ERROR - 2015-09-14 16:04:52 --> Severity: Parsing Error --> syntax error, unexpected 'for' (T_FOR), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-14 16:05:34 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 709
ERROR - 2015-09-14 16:11:47 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:11:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:12:22 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:12:22 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:14:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:14:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:15:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:15:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:19:51 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:19:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:21:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:21:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:22:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:22:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:24:33 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:24:33 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 16:25:57 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:29:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:32:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 16:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 16:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 16:40:15 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:48:24 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:48:24 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:48:24 --> Severity: Notice --> Undefined variable: cantidad_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:50:29 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:50:29 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 665
ERROR - 2015-09-14 16:50:29 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:50:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:51:27 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 668
ERROR - 2015-09-14 16:51:27 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:52:21 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:55:34 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/b_xmlcaso2_view.php 85
ERROR - 2015-09-14 16:56:28 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:57:16 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:57:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:58:46 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 16:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:00:10 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:00:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:02:17 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:07:34 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:07:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:10:28 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:21:41 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 17:21:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 17:23:02 --> Severity: Notice --> Undefined variable: oc_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 17:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 17:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 207
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 208
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 209
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 8
ERROR - 2015-09-14 17:26:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-14 17:26:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 17:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:35:49 --> Severity: Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 107
ERROR - 2015-09-14 17:36:05 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 39
ERROR - 2015-09-14 17:36:05 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-14 17:36:05 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-14 17:36:05 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-14 17:36:05 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 150
ERROR - 2015-09-14 17:36:05 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/views/b_xmlcaso2_view.php 107
ERROR - 2015-09-14 17:36:10 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/views/b_xmlcaso2_view.php 107
ERROR - 2015-09-14 17:36:43 --> Severity: Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 107
ERROR - 2015-09-14 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 17:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:49:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:49:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:53:05 --> Severity: Notice --> Undefined variable: all_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 663
ERROR - 2015-09-14 17:53:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 17:53:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:53:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:53:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:53:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-14 17:57:33 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 418
ERROR - 2015-09-14 18:00:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 676
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 678
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 683
ERROR - 2015-09-14 18:00:02 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 18:09:18 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:09:18 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 673
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 680
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 682
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-14 18:09:18 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 18:30:31 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:30:31 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 671
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 673
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 18:30:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 18:30:31 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 18:30:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 18:32:06 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:32:06 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 18:32:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 671
ERROR - 2015-09-14 18:32:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 673
ERROR - 2015-09-14 18:32:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-14 18:32:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-14 18:32:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 18:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 18:43:13 --> Query error: Unknown column 'unidad' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `unidad`, `modelo`, `descripcion`, `valorunitario`, `fecha_ingreso`, `noserie`, `nopieza`) VALUES ('4', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-14 19:31:54 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 19:31:54 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 671
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 673
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 675
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 19:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-14 19:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-14 19:31:54 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 725
ERROR - 2015-09-14 19:34:19 --> Query error: Unknown column 'unidad' in 'field list' - Invalid query: INSERT INTO `productos` (`cantidad`, `unidad`, `modelo`, `descripcion`, `valorunitario`, `fecha_ingreso`, `noserie`, `nopieza`) VALUES ('4', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-14 19:42:06 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 19:42:06 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 19:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-14 19:42:06 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 705
ERROR - 2015-09-14 19:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 705
ERROR - 2015-09-14 19:58:25 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 19:58:25 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 19:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-14 19:58:25 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 705
ERROR - 2015-09-14 19:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 705
ERROR - 2015-09-14 20:06:07 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:06:07 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:06:07 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-14 20:08:59 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:08:59 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:08:59 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-14 20:10:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:10:13 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:10:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:10:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:10:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:10:13 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 703
ERROR - 2015-09-14 20:12:52 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:12:52 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:12:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:12:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:15:13 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:15:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:16:32 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:16:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 716
ERROR - 2015-09-14 20:17:20 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-14 20:17:51 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:17:51 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 706
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:17:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:27:10 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:27:10 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:27:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:27:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:29:43 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 715
ERROR - 2015-09-14 20:30:03 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:30:03 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:30:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:30:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:30:03 --> Severity: Warning --> Missing argument 2 for B_up_xml_model::solicita_productos_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 691 and defined /var/www/html/ci/application/models/B_up_xml_model.php 106
ERROR - 2015-09-14 20:30:03 --> Severity: Warning --> Missing argument 3 for B_up_xml_model::solicita_productos_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 691 and defined /var/www/html/ci/application/models/B_up_xml_model.php 106
ERROR - 2015-09-14 20:30:03 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/models/B_up_xml_model.php 112
ERROR - 2015-09-14 20:30:03 --> Severity: Notice --> Undefined variable: noserie /var/www/html/ci/application/models/B_up_xml_model.php 114
ERROR - 2015-09-14 20:30:03 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES (NULL, NULL, NULL)
ERROR - 2015-09-14 20:30:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-14 20:32:22 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:32:22 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 693
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:32:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:33:19 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:33:19 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:37:51 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 782
ERROR - 2015-09-14 20:39:59 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:39:59 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:45:03 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:45:03 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:45:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 687
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-14 20:45:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:45:03 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-14 20:54:23 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:54:23 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 20:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-14 20:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-14 20:54:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720

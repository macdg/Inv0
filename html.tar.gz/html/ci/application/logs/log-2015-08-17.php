<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-17 12:16:53 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-17 12:16:53 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 12:16:53 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-17 12:16:53 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 115
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/Up_xml_controller.php 117
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 120
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 12:36:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 12:36:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 12:36:49 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 12:36:49 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 115
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/Up_xml_controller.php 117
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 120
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 12:43:08 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 12:43:08 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 12:43:08 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 12:43:08 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 115
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/Up_xml_controller.php 117
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 120
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 12:51:22 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 12:51:22 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 12:51:22 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 12:51:22 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> readfile(/root/Documentos/rep_xml/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> filesize(): stat failed for /root/Documentos/rep_xml/archivo.php /var/www/html/ci/application/controllers/Up_xml_controller.php 125
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> fopen(/root/Documentos/rep_xml/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 128
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 12:59:33 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 12:59:33 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 12:59:33 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 12:59:33 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/Up_xml_controller.php 206
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:03:51 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:03:51 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:03:51 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:03:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:04:04 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:04:04 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:04:04 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:04:04 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:08:59 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:08:59 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:08:59 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:08:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:09:09 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:09:09 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:09:09 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 194
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:09:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 200
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:12:00 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:12:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:12:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:12:00 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:12:00 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:12:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:12:11 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:12:11 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:12:11 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:12:11 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:12:11 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:12:11 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:14:05 --> Severity: Parsing Error --> syntax error, unexpected '$mi_archivo_1' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 99
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:14:52 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:14:52 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:14:52 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:14:52 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:14:52 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:14:52 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:15:01 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:15:01 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:15:01 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:15:01 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:15:01 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:15:01 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:15:54 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:15:54 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:15:54 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:15:54 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:15:54 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:15:54 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:16:05 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:16:05 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:16:05 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:16:05 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:16:05 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 195
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 199
ERROR - 2015-08-17 13:16:05 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 201
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:17:18 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:17:18 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:17:31 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:17:31 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 120
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 121
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 128
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 130
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 146
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 147
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 157
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 164
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 166
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 176
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:24:14 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:24:14 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 120
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 121
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 128
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 130
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 145
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 146
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 147
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 157
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 164
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 166
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 176
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:24:36 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:24:36 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 109
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:26:39 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:26:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:27:00 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 198
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 13:27:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 109
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 132
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:29:13 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 13:29:13 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 109
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:30:35 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 13:30:35 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:30:51 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 13:30:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 109
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 132
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:31:30 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 13:31:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 128
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 132
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:31:47 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 13:31:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 109
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 131
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 133
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:38:10 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 208
ERROR - 2015-08-17 13:38:10 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 107
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 123
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 131
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 133
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 148
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 131
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 133
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:40:33 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 208
ERROR - 2015-08-17 13:40:33 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 108
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 111
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 125
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 134
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 141
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 143
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 151
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 153
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 161
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 170
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 173
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 131
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 133
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:57:30 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 208
ERROR - 2015-08-17 13:57:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 108
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 125
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 134
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 141
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 143
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 151
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 153
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 161
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 170
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 173
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 129
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 130
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 131
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 133
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:57:49 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 208
ERROR - 2015-08-17 13:57:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 108
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 110
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 111
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 124
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 125
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 134
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 140
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 141
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 143
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 149
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 151
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 153
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 159
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 161
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 170
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 173
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: error /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 146
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 221
ERROR - 2015-08-17 14:07:39 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 221
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 225
ERROR - 2015-08-17 14:07:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 14:43:03 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/ci/application/controllers/Up_xml_controller.php 30
ERROR - 2015-08-17 14:43:14 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/ci/application/controllers/Up_xml_controller.php 30
ERROR - 2015-08-17 14:43:29 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/ci/application/controllers/Up_xml_controller.php 30
ERROR - 2015-08-17 14:44:14 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ')' /var/www/html/ci/application/controllers/Up_xml_controller.php 32
ERROR - 2015-08-17 14:46:51 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ')' /var/www/html/ci/application/controllers/Up_xml_controller.php 32
ERROR - 2015-08-17 14:46:55 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ')' /var/www/html/ci/application/controllers/Up_xml_controller.php 32
ERROR - 2015-08-17 14:47:19 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ')' /var/www/html/ci/application/controllers/Up_xml_controller.php 32
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 14:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:47:47 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:47:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 14:47:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 14:49:49 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 30
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 14:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:51:06 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:51:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 14:51:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 14:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:52:06 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 14:52:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 14:52:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:01:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:01:39 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:01:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:01:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:05:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:05:57 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:05:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:05:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:09:38 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:09:38 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:09:38 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:10:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:10:57 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:10:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:10:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:13:22 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:13:22 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:13:22 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:18:53 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:18:53 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:18:53 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:19:25 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:19:25 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:19:25 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:19:42 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:19:42 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:19:42 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:21:37 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:21:37 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:21:37 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:22:40 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:22:40 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:22:40 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:23:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:23:51 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:23:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:23:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:26:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:25 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:25 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:26:25 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:26:50 --> You did not select a file to upload.
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 202
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 210
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 134
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 151
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 166
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 175
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 176
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 177
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 185
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 186
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 187
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 189
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 195
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 206
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 147
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:50 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 222
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 226
ERROR - 2015-08-17 15:26:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:29:59 --> You did not select a file to upload.
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 134
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 137
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 150
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 151
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 166
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 167
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 175
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 176
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 177
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 185
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 186
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 187
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 189
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 195
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 206
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:29:59 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:29:59 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:30:07 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:30:07 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:30:07 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:30:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:30:26 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:30:26 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:30:26 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:31:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Use of undefined constant form_open_multipart - assumed 'form_open_multipart' /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:31:36 --> Severity: Notice --> Use of undefined constant form - assumed 'form' /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:31:36 --> Severity: Warning --> Division by zero /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:31:36 --> Severity: Error --> Call to undefined function data() /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:33:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:33:07 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:33:07 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:33:07 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:33:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:33:47 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:33:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:33:47 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:35:08 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:35:08 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:35:08 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:37:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:37:02 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:37:02 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:37:02 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:37:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 148
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 152
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 154
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 203
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 211
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:37:19 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 223
ERROR - 2015-08-17 15:37:19 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 227
ERROR - 2015-08-17 15:37:19 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 229
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:48:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 156
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:48:57 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:48:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:48:57 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:49:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 156
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:49:20 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:49:20 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:49:20 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:50:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 156
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:50:00 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:50:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:50:00 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:53:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 155
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 156
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:53:51 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:53:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:53:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:54:09 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:54:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:54:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 17
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 18
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 19
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 149
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 150
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 151
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 153
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: encab_sock /var/www/html/ci/application/views/up_xml_view.php 204
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero1 /var/www/html/ci/application/views/up_xml_view.php 205
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero2 /var/www/html/ci/application/views/up_xml_view.php 206
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: string_fichero3 /var/www/html/ci/application/views/up_xml_view.php 207
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/views/up_xml_view.php 212
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:55:26 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 224
ERROR - 2015-08-17 15:55:26 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 228
ERROR - 2015-08-17 15:55:26 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 230
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 138
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 153
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 177
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 178
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 187
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 188
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 189
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 197
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 208
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 138
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 140
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 141
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 15:57:13 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 15:57:13 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 136
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 152
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 153
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 160
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 169
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 177
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 178
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 179
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 187
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 188
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 189
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 197
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 208
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 138
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 15:57:36 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 15:57:36 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 141
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 138
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 140
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 141
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:03:49 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:03:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 134
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 135
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: mi_archivo_1 /var/www/html/ci/application/views/up_xml_view.php 136
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/views/up_xml_view.php 138
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:04:09 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:04:09 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-17 16:09:31 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-17 16:09:31 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 16:09:31 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-17 16:09:31 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-17 16:10:28 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-17 16:10:28 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 16:10:28 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-17 16:10:28 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 141
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/Up_xml_controller.php 142
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:10:32 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:10:32 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/Up_xml_controller.php 139
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:10:49 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:10:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:14:49 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:14:49 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:15:06 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:15:06 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:16:37 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:16:37 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:16:51 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:16:51 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:17:48 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/html/ci/application/controllers/Up_xml_controller.php 130
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:18:39 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:18:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:18:50 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:18:50 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:16 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:23:16 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:18 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:23:18 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 155
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 156
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 168
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 171
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 172
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 181
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 182
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 184
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 190
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 191
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 192
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/Up_xml_controller.php 200
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 204
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: nom_archivo /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/up_xml_view.php 20
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/up_xml_view.php 104
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:30 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/up_xml_view.php 209
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 213
ERROR - 2015-08-17 16:23:30 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/up_xml_view.php 215
ERROR - 2015-08-17 16:25:12 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 18
ERROR - 2015-08-17 16:32:16 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 132
ERROR - 2015-08-17 17:01:40 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-17 17:02:29 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-17 17:18:47 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/Up_xml_controller.php 158
ERROR - 2015-08-17 17:24:26 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:24:51 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:25:07 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:26:23 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:26:26 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:28:59 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting '(' /var/www/html/ci/application/controllers/Up_xml_controller.php 162
ERROR - 2015-08-17 17:55:55 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 17:56:17 --> Severity: Parsing Error --> syntax error, unexpected 'y' (T_STRING), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 174
ERROR - 2015-08-17 18:13:58 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/Up_xml_controller.php 187
ERROR - 2015-08-17 20:05:18 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/Up_xml_controller.php 12
ERROR - 2015-08-17 20:06:12 --> Severity: Error --> Call to undefined method CI_Loader::controller() /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 20:07:05 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/html/ci/application/controllers/Up_xml_controller.php 163
ERROR - 2015-08-17 20:07:32 --> Severity: Parsing Error --> syntax error, unexpected ''up_xml_controller'' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/html/ci/application/controllers/Up_xml_controller.php 163

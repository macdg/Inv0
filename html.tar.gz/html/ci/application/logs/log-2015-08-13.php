<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined index: num_mi_fila /var/www/ci/application/views/inv_v.php 27
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 45
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 46
ERROR - 2015-08-13 10:17:18 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 47
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 56
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 57
ERROR - 2015-08-13 12:47:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 58
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/controllers/Inv_c.php 47
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 56
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 57
ERROR - 2015-08-13 12:52:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 58
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 56
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 57
ERROR - 2015-08-13 12:55:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 58
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 13:02:19 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 13:03:03 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 13:04:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 19:36:31 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 19:46:38 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 19:46:40 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 81
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 82
ERROR - 2015-08-13 19:46:58 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:47:59 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:48:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:48:10 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:48:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:48:21 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 83
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:48:39 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:53:29 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 86
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:54:50 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 86
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:56:22 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 86
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 84
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 85
ERROR - 2015-08-13 19:59:20 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 86
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 95
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 96
ERROR - 2015-08-13 20:02:07 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 97
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 95
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 96
ERROR - 2015-08-13 20:02:08 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 97
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined index:  /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 95
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 96
ERROR - 2015-08-13 20:02:45 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 97
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 33
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 36
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 37
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined index: num_mi_fila1 /var/www/ci/application/controllers/Inv_c.php 39
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/ci/application/views/inv_v.php 8
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 95
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined variable: creando_tabla_row /var/www/ci/application/views/inv_v.php 96
ERROR - 2015-08-13 20:04:56 --> Severity: Notice --> Undefined variable: num_mi_fila /var/www/ci/application/views/inv_v.php 97

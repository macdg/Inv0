<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-21 10:44:01 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 39
ERROR - 2015-09-21 10:44:01 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-21 10:44:01 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-21 10:44:01 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-21 10:44:01 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 150
ERROR - 2015-09-21 10:44:01 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 11:38:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SU CONSULTA' at line 1 - Invalid query: SU CONSULTA
ERROR - 2015-09-21 11:39:49 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::query1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 598
ERROR - 2015-09-21 11:40:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:40:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:40:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:40:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:41:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:41:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:41:59 --> Severity: Error --> Call to a member function row() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 602
ERROR - 2015-09-21 11:42:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:42:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:43:48 --> Severity: Parsing Error --> syntax error, unexpected 'isset' (T_ISSET) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 11:43:52 --> Severity: Parsing Error --> syntax error, unexpected 'isset' (T_ISSET) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 11:44:13 --> Severity: Parsing Error --> syntax error, unexpected 'isset' (T_ISSET) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 11:44:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:44:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:50:42 --> Severity: Error --> Call to a member function isset() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 11:57:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:57:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:58:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 11:58:46 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 12:00:17 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 12:00:17 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 12:00:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 12:00:26 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 13:13:02 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 630
ERROR - 2015-09-21 13:39:14 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 614
ERROR - 2015-09-21 14:17:05 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 14:24:39 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-21 14:26:45 --> Severity: Error --> Call to a member function result() on string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-21 14:27:26 --> Severity: Error --> Call to a member function result() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-21 14:35:48 --> Severity: Parsing Error --> syntax error, unexpected '$consulta' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-21 15:02:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 630
ERROR - 2015-09-21 15:43:23 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-21 15:44:10 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 587
ERROR - 2015-09-21 15:44:24 --> Severity: Error --> Call to a member function result_array() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-21 15:45:28 --> Severity: Error --> Call to a member function result_array() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-21 15:45:53 --> Severity: Error --> Call to a member function result() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-21 16:03:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 638
ERROR - 2015-09-21 16:04:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-21 16:04:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-21 16:08:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 437
ERROR - 2015-09-21 16:08:54 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 639
ERROR - 2015-09-21 16:09:16 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 639
ERROR - 2015-09-21 16:09:43 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 639
ERROR - 2015-09-21 16:10:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 639
ERROR - 2015-09-21 16:24:25 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 16:32:43 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-21 16:33:02 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 16:47:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-21 16:48:20 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-21 16:48:44 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 559
ERROR - 2015-09-21 16:53:39 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::isset() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-21 16:53:59 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-21 16:54:17 --> Severity: Error --> Call to a member function result() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 16:54:55 --> Severity: Error --> Call to a member function result_array() on null /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:05:48 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:06:02 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:15:59 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:17:35 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:22:40 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2015-09-21 17:23:54 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:26:08 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:28:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 17:29:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 17:30:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/system/helpers/text_helper.php 317
ERROR - 2015-09-21 17:32:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''concepto'' at line 1 - Invalid query:  SELECT 'id_uuid' FROM 'concepto' 
ERROR - 2015-09-21 17:33:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''concepto'' at line 1 - Invalid query:  SELECT 'id_uuid' FROM 'concepto' 
ERROR - 2015-09-21 17:34:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''concepto'' at line 1 - Invalid query:  SELECT 'id_uuid' FROM 'concepto' 
ERROR - 2015-09-21 17:36:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''concepto'' at line 1 - Invalid query:  SELECT 'id_uuid' FROM 'concepto'; 
ERROR - 2015-09-21 17:44:46 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 17:46:05 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 17:46:33 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 17:46:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 17:52:43 --> Severity: Parsing Error --> syntax error, unexpected '&&' (T_BOOLEAN_AND) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:53:14 --> Severity: Parsing Error --> syntax error, unexpected '&&' (T_BOOLEAN_AND) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 17:55:35 --> Severity: Parsing Error --> syntax error, unexpected '&&' (T_BOOLEAN_AND) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 561
ERROR - 2015-09-21 18:06:21 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 18:10:11 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 18:14:23 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 595
ERROR - 2015-09-21 18:15:53 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 18:21:00 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 597
ERROR - 2015-09-21 18:21:25 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 596
ERROR - 2015-09-21 18:29:01 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-21 18:30:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:30:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:30:34 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 18:34:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:34:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:34:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:35:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:35:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:35:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 18:40:32 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 564
ERROR - 2015-09-21 18:58:23 --> Severity: Parsing Error --> syntax error, unexpected 'for' (T_FOR) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 606
ERROR - 2015-09-21 19:01:43 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 619
ERROR - 2015-09-21 19:01:47 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 619
ERROR - 2015-09-21 19:01:50 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 619
ERROR - 2015-09-21 19:02:24 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 619
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 19:02:51 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 600
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 598
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 598
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 598
ERROR - 2015-09-21 19:04:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 598
ERROR - 2015-09-21 19:07:59 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 596
ERROR - 2015-09-21 19:08:08 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 657
ERROR - 2015-09-21 19:11:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:11:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:12:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:12:36 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:13:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:13:30 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:13:56 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:30:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:30:23 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:30:59 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 552
ERROR - 2015-09-21 19:40:53 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 669
ERROR - 2015-09-21 19:55:54 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 866
ERROR - 2015-09-21 19:56:19 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-21 20:00:09 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 20:01:11 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-21 20:01:11 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-21 20:01:11 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-21 20:01:11 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 150
ERROR - 2015-09-21 20:01:11 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 20:01:22 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)
ERROR - 2015-09-21 20:04:03 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('4FFB3E12-5CF2-AA48-B533-986FAC14F7DA', NULL, NULL, NULL, NULL)

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-03 09:35:43 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:35:43 --> Severity: Notice --> Undefined variable: nomo /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 09:35:43 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:35:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:109) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-03 09:35:43 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 109
ERROR - 2015-09-03 09:38:53 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:38:53 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:38:53 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:39:00 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:39:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:39:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:39:30 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:39:56 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:39:58 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:40:32 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:40:48 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:41:19 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting variable (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 106
ERROR - 2015-09-03 09:41:31 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:41:31 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:41:31 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:41:56 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:41:56 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:41:56 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:41:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:41:59 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:41:59 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:42:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 09:42:36 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:42:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 09:42:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 09:44:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 09:44:36 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:44:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 09:44:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 09:44:36 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 09:45:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 09:45:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 09:45:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:45:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 09:45:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 09:45:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 09:46:12 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 09:46:12 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 09:46:12 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 09:46:12 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 09:46:12 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 09:46:12 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:26:25 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:26:25 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 10:26:25 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:26:25 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:26:25 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:26:25 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:26:51 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:26:51 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:26:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 10:26:51 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:26:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:26:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:26:51 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:27:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:27:02 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:27:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 10:27:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:27:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:27:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:27:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:27:14 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:27:14 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:27:46 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:27:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:27:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:28:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:28:02 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:28:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 10:28:02 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:28:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:28:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:28:02 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:34:23 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 10:34:23 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:34:23 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 101
ERROR - 2015-09-03 10:34:23 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:34:23 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 117
ERROR - 2015-09-03 10:35:07 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:35:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:35:07 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:35:52 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:35:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:35:52 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 92
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 95
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 112
ERROR - 2015-09-03 10:36:00 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 10:36:25 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:36:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:36:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:45:09 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:46:20 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:46:25 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:46:58 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:46:58 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:47:06 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:47:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:47:06 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:50:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:50:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:50:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:50:49 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:50:49 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:50:49 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-03 10:51:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:51:05 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:51:05 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-03 10:52:13 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:52:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:52:13 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:52:23 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:52:23 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:52:23 --> Severity: Error --> Call to undefined function subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-03 10:52:47 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:52:47 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:52:47 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:52:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:52:47 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:52:47 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 118
ERROR - 2015-09-03 10:54:21 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:54:21 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:54:21 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:54:21 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 10:54:21 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 10:54:21 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 118
ERROR - 2015-09-03 10:55:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:55:34 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 108
ERROR - 2015-09-03 10:55:34 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:55:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:100) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-03 10:55:34 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:55:59 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:55:59 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:56:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:56:30 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:56:34 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:56:34 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:56:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:56:37 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:56:41 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:56:41 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:56:49 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 10:56:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 10:56:49 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 10:56:57 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:57:03 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:57:03 --> Severity: Error --> Call to undefined method CI_Loader::b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:58:17 --> Severity: Parsing Error --> syntax error, unexpected ''b_up_xml_controller1/b_conten' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:59:00 --> Severity: Parsing Error --> syntax error, unexpected ''b_up_xml_controller1/b_conten' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 100
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 10:59:38 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 161
ERROR - 2015-09-03 10:59:58 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:06 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 114
ERROR - 2015-09-03 11:00:06 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 118
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:00:24 --> Severity: Error --> Maximum function nesting level of '100' reached, aborting! /var/www/html/ci/system/core/Log.php 168
ERROR - 2015-09-03 11:01:38 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:01:38 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 11:01:46 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:01:46 --> Severity: Error --> Call to undefined function b_contenido_xml_1() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 102
ERROR - 2015-09-03 11:04:20 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:04:25 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:04:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:04:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:04:43 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:04:43 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 111
ERROR - 2015-09-03 11:04:43 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 115
ERROR - 2015-09-03 11:20:10 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:20:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:20:10 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:20:40 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:20:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:20:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:21:18 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:21:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:21:18 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:51:47 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:51:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:51:48 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:51:52 --> Severity: Error --> Using $this when not in object context /var/www/html/ci/application/controllers/B_up_xml_controller1.php 103
ERROR - 2015-09-03 11:52:47 --> Severity: Error --> Call to undefined method CI_Controller::subiendo_archivo() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 110
ERROR - 2015-09-03 11:53:08 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:53:08 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:53:08 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:53:08 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:53:20 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:53:20 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:53:20 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:54:16 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:54:16 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:54:16 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:54:49 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:54:49 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 92
ERROR - 2015-09-03 11:54:49 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 95
ERROR - 2015-09-03 11:54:49 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:54:49 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:54:54 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:54:54 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 92
ERROR - 2015-09-03 11:54:54 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 95
ERROR - 2015-09-03 11:54:54 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:54:54 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:55:10 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:55:10 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:55:10 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:55:17 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:55:34 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:55:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:55:34 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:55:41 --> Severity: Error --> Using $this when not in object context /var/www/html/ci/application/controllers/B_up_xml_controller1.php 103
ERROR - 2015-09-03 11:56:22 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:56:22 --> Severity: Error --> Using $this when not in object context /var/www/html/ci/application/controllers/B_up_xml_controller1.php 103
ERROR - 2015-09-03 11:56:32 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:56:32 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 116
ERROR - 2015-09-03 11:56:32 --> Severity: Notice --> Undefined variable: val_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 120
ERROR - 2015-09-03 11:57:56 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:57:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:57:56 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43
ERROR - 2015-09-03 11:58:01 --> Severity: Error --> Using $this when not in object context /var/www/html/ci/application/controllers/B_up_xml_controller1.php 103
ERROR - 2015-09-03 11:59:37 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 66
ERROR - 2015-09-03 11:59:47 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 41
ERROR - 2015-09-03 11:59:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 42
ERROR - 2015-09-03 11:59:47 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 43

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-14 11:13:10 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Trab_control' does not have a method 'index' /var/www/ci/system/core/CodeIgniter.php 514

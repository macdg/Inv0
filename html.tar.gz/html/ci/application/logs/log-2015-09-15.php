<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-15 09:49:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 09:49:38 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 09:49:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 09:49:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 09:49:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:00:02 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:00:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:01:34 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:01:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:04:34 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:04:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:06:50 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 701
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 712
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:06:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 10:11:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:11:38 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-15 10:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:11:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:13:29 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:13:29 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 685
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:13:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-15 10:13:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 700
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:13:29 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 719
ERROR - 2015-09-15 10:16:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:18:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:20:42 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:20:42 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:20:42 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:20:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:21:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:23:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:24:16 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:24:16 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:24:16 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:24:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:27:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:28:15 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:28:15 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:28:15 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:28:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 10:30:59 --> Severity: Parsing Error --> syntax error, unexpected '&' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:31:12 --> Severity: Parsing Error --> syntax error, unexpected '&' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:38:51 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:38:51 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:38:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:42:39 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:42:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:45:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 411
ERROR - 2015-09-15 10:46:11 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:46:11 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 411
ERROR - 2015-09-15 10:46:52 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:46:52 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:46:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:58:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 411
ERROR - 2015-09-15 10:59:16 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:59:16 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:59:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:59:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 10:59:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:42:13 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:42:13 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 11:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 11:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:42:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:45:27 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:45:27 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 692
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 11:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 695
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 708
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 11:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:45:27 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 730
ERROR - 2015-09-15 11:46:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:47:06 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:47:06 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:47:06 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 694
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-15 11:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-15 11:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:47:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:48:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 11:48:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:50:44 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:50:44 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:50:44 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 670
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 672
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 674
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 677
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 679
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 681
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 694
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-15 11:50:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 697
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-15 11:50:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 724
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:50:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 732
ERROR - 2015-09-15 11:53:07 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:53:07 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:53:07 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 11:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:53:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:55:32 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:55:32 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 691
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 11:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 707
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 718
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 11:55:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 726
ERROR - 2015-09-15 12:02:21 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:09:09 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:09:09 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:09:09 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:09:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:09:09 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 734
ERROR - 2015-09-15 12:09:09 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES (NULL, '4', '0001')
ERROR - 2015-09-15 12:09:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-15 12:11:54 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:11:54 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:11:54 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:11:54 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 735
ERROR - 2015-09-15 12:11:54 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES (NULL, NULL, '0001')
ERROR - 2015-09-15 12:11:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-15 12:14:48 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:14:48 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:14:48 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:14:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:14:48 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:16:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:16:05 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:16:05 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:16:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:16:23 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:17:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:17:13 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:17:13 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:17:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:17:13 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:18:55 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:18:55 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:18:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:28:50 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:28:50 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: k /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: val /var/www/html/ci/application/controllers/B_up_xml_controller1.php 722
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 731
ERROR - 2015-09-15 12:28:50 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 741
ERROR - 2015-09-15 12:32:50 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:34:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:34:05 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:34:05 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:34:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:34:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:34:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:34:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:34:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 720
ERROR - 2015-09-15 12:39:38 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:46:58 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:47:10 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:47:45 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `productos` (`id_uuid`, `cantidad`, `noserie`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL)
ERROR - 2015-09-15 12:50:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:50:02 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:50:02 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:50:02 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:50:02 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:50:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:50:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 744
ERROR - 2015-09-15 12:58:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:58:41 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:58:41 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 12:58:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 12:58:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 12:58:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 12:58:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 744
ERROR - 2015-09-15 13:22:32 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 13:22:32 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 13:22:32 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-15 13:22:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-15 13:22:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-15 13:22:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 13:22:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-15 13:22:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 765
ERROR - 2015-09-15 13:22:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 773
ERROR - 2015-09-15 13:24:31 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: INSERT INTO `productos` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5`) VALUES ('')

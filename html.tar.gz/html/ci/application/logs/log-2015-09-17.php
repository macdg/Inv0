<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-17 10:23:28 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:23:28 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:23:28 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:23:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 10:23:28 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 10:23:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:23:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 781
ERROR - 2015-09-17 10:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 781
ERROR - 2015-09-17 10:56:39 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:56:39 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:56:39 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:56:39 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 10:56:39 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 10:56:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:56:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:56:39 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 10:56:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 10:59:24 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:59:24 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:59:24 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 10:59:24 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 10:59:24 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 10:59:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 10:59:24 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 10:59:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:00:39 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:00:39 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:00:39 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:00:39 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:00:39 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 837
ERROR - 2015-09-17 11:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 837
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:02:35 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:02:35 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:02:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:02:35 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:02:35 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:02:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:04:29 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:04:29 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:04:29 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:04:29 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:04:29 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:08:06 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:09:41 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:10:37 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:12:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:12:25 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:26 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:26 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:26 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:12:26 --> Severity: Notice --> Undefined index: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 11:12:26 --> Severity: Notice --> Undefined index: noserie /var/www/html/ci/application/controllers/B_up_xml_controller1.php 847
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:13:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 849
ERROR - 2015-09-17 11:13:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 850
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:17:02 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:19:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:19:38 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 842
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:22:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 843
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 855
ERROR - 2015-09-17 11:23:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 855
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:24:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:24:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:26:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:26:23 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:27:19 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:29:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:29:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Benchmark could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Hooks could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Config could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Log could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Utf8 could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_URI could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Router could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Output could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Security could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Lang could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Upload could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class B_up_xml_model could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class B_up_xml_model could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:07 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Benchmark could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Hooks could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Config could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Log could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Utf8 could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_URI could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Router could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Output could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Security could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Lang could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Upload could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class B_up_xml_model could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class B_up_xml_model could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:31:47 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:32:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 863
ERROR - 2015-09-17 11:33:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:34:00 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:34:25 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 11:34:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:35:09 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:37:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:37:52 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:40:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:40:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:41:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:41:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Missing argument 4 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:42:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:42:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:43:43 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:43:43 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:43:43 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:43:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:46:20 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:46:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:48:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:51:07 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:51:07 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:52:48 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:52:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:54:55 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:54:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 11:56:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:06:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:09:20 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 667
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 713
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 794
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 795
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:34:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:38:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:38:24 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:41:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:42:51 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 12:42:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 12:44:39 --> Severity: Parsing Error --> syntax error, unexpected ''datos_concepto'' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 867
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:47:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:52:15 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 874
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:53:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:53:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:53:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:53:47 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 874
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:55:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:55:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:55:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 12:55:25 --> Severity: Warning --> Illegal string offset 'datos_concepto' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 874
ERROR - 2015-09-17 12:58:55 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 871
ERROR - 2015-09-17 13:01:33 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 870
ERROR - 2015-09-17 13:02:58 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 870
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:07:12 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:12:05 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:13:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:14:34 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:16:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:16:28 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:17:37 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:17:37 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:17:37 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 877
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 859
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:18:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 864
ERROR - 2015-09-17 13:18:32 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 868
ERROR - 2015-09-17 13:18:32 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 877
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 840
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:20:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:20:49 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Undefined variable: oc_datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 840
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:24:31 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:24:31 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:29:28 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:29:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:29:28 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:32:13 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 661
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 704
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 710
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 784
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 823
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 860
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:32:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 865
ERROR - 2015-09-17 13:32:13 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 13:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 869
ERROR - 2015-09-17 14:09:57 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 727
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 733
ERROR - 2015-09-17 14:09:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 733
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 807
ERROR - 2015-09-17 14:09:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 807
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 861
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 862
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 883
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 883
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 888
ERROR - 2015-09-17 14:09:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 888
ERROR - 2015-09-17 14:09:57 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 892
ERROR - 2015-09-17 14:09:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 892
ERROR - 2015-09-17 14:10:33 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::solicitar2() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 684
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 711
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 727
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 733
ERROR - 2015-09-17 14:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 733
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 807
ERROR - 2015-09-17 14:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 807
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 846
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: total_reg /var/www/html/ci/application/controllers/B_up_xml_controller1.php 861
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Undefined variable: changos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 862
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 883
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 883
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 888
ERROR - 2015-09-17 14:10:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 888
ERROR - 2015-09-17 14:10:33 --> Severity: Warning --> Illegal string offset 'array' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 892
ERROR - 2015-09-17 14:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 892
ERROR - 2015-09-17 14:11:41 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:20:26 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:22:25 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:25:11 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:26:22 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:27:47 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 14:42:07 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', Array, Array, Array, Array)
ERROR - 2015-09-17 14:58:11 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `concepto` () VALUES ('')
ERROR - 2015-09-17 15:00:31 --> Query error: Duplicate entry 'cantidad' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`) VALUES ('cantidad')
ERROR - 2015-09-17 15:02:38 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 15:15:01 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('', NULL, NULL, NULL, NULL)
ERROR - 2015-09-17 16:20:16 --> Severity: Parsing Error --> syntax error, unexpected '$datos_concepto_union' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 593
ERROR - 2015-09-17 16:20:57 --> Severity: Parsing Error --> syntax error, unexpected '$datos_concepto_union' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 597
ERROR - 2015-09-17 16:21:52 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD.A101E,426.7900' in 'field list' - Invalid query: INSERT INTO `concepto` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD`. `A101E,426`.`7900`) VALUES ('')
ERROR - 2015-09-17 16:23:26 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD.A101E,426.7900' in 'field list' - Invalid query: INSERT INTO `concepto` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD`. `A101E,426`.`7900`) VALUES ('')
ERROR - 2015-09-17 16:27:59 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD.A101E,426.7900' in 'field list' - Invalid query: INSERT INTO `concepto` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD`. `A101E,426`.`7900`) VALUES ('')
ERROR - 2015-09-17 16:40:02 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD.A101E,426.7900' in 'field list' - Invalid query: INSERT INTO `concepto` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD`. `A101E,426`.`7900`) VALUES ('')
ERROR - 2015-09-17 16:46:11 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD.A101E,426.7900' in 'field list' - Invalid query: INSERT INTO `concepto` (`32f7865e-5ee9-46b0-857d-30cc9b7d68b5,4,pz,SANGOMA TARJETA AFT 1 T1/E1 MOD`. `A101E,426`.`7900`) VALUES ('')
ERROR - 2015-09-17 16:49:54 --> Query error: Duplicate entry 'cantidad' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`) VALUES ('cantidad')
ERROR - 2015-09-17 17:00:12 --> Query error: Duplicate entry 'cantidad' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`) VALUES ('cantidad')
ERROR - 2015-09-17 17:00:45 --> Query error: Duplicate entry 'cantidad' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`) VALUES ('cantidad')
ERROR - 2015-09-17 17:05:09 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 17:12:47 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 17:41:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '33 = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'' at line 1 - Invalid query: UPDATE `concepto` SET 33 = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 17:48:43 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 17:52:20 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` IN('32f7865e-5ee9-46b0-857d-30cc9b7d68b5')
ERROR - 2015-09-17 17:55:16 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 17:56:10 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 18:05:20 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:06:19 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:06:58 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:12:40 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:14:53 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:15:41 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:16:43 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:17:56 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:19:22 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:20:12 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:20:35 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:25:32 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:29:40 --> Query error: Duplicate entry '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'PRIMARY' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:34:33 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:35:01 --> Query error: Unknown column '32f7865e-5ee9-46b0-857d-30cc9b7d68b5' in 'field list' - Invalid query: UPDATE `concepto` SET `32f7865e-5ee9-46b0-857d-30cc9b7d68b5` = ''
WHERE `id_uuid` = '32f7865e-5ee9-46b0-857d-30cc9b7d68b5'
ERROR - 2015-09-17 19:49:43 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:53:14 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:54:01 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:54:47 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:55:18 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:56:37 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 19:59:28 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '4', 'pz', 'SANGOMA TARJETA AFT 1 T1/E1 MOD. A101E', '426.7900')
ERROR - 2015-09-17 20:16:57 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563
ERROR - 2015-09-17 20:17:57 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 563

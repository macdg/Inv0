<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-02 09:44:42 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 342
ERROR - 2015-10-02 10:40:02 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `productos`
WHERE `id` =0
ERROR - 2015-10-02 11:40:57 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `productos`
WHERE `id` = 14
ERROR - 2015-10-02 11:42:46 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `productos`
WHERE `id` = 15
ERROR - 2015-10-02 11:46:24 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `productos`
WHERE `id` = 16
ERROR - 2015-10-02 11:48:50 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `productos`
WHERE `id` = 17
ERROR - 2015-10-02 11:57:00 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 320
ERROR - 2015-10-02 11:57:12 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 320
ERROR - 2015-10-02 11:57:26 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 320
ERROR - 2015-10-02 11:58:14 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 320
ERROR - 2015-10-02 11:58:59 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 320
ERROR - 2015-10-02 12:03:12 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 304
ERROR - 2015-10-02 12:03:42 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-02 12:03:42 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:04:00 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-02 12:04:00 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:04:45 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-02 12:04:45 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:06:10 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-02 12:06:10 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:07:10 --> Severity: 4096 --> Object of class CI_Form_validation could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller2.php 290
ERROR - 2015-10-02 12:07:10 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:07:41 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:08:12 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:11:18 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:12:29 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:12:45 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:12:45 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 12:13:00 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:13:00 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 12:13:11 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:13:11 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 12:14:18 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:14:27 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:14:46 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 294
ERROR - 2015-10-02 12:18:55 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 302
ERROR - 2015-10-02 12:19:28 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 302
ERROR - 2015-10-02 12:20:32 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 302
ERROR - 2015-10-02 12:26:49 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 12:26:49 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 324
ERROR - 2015-10-02 12:26:49 --> Severity: Notice --> Undefined variable: elementos /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-02 12:27:03 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 12:27:03 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 324
ERROR - 2015-10-02 12:27:03 --> Severity: Notice --> Undefined variable: elementos /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-02 12:36:39 --> Severity: Parsing Error --> syntax error, unexpected '!=' (T_IS_NOT_EQUAL) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 293
ERROR - 2015-10-02 12:42:19 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 308
ERROR - 2015-10-02 12:42:19 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 323
ERROR - 2015-10-02 12:42:31 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 308
ERROR - 2015-10-02 12:42:31 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 323
ERROR - 2015-10-02 12:44:36 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 12:44:36 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-02 12:45:05 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 12:45:05 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 325
ERROR - 2015-10-02 12:46:17 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 295
ERROR - 2015-10-02 12:46:58 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 298
ERROR - 2015-10-02 12:50:56 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 12:51:13 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 349
ERROR - 2015-10-02 12:51:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 298
ERROR - 2015-10-02 12:51:28 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:53:15 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:53:15 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 330
ERROR - 2015-10-02 12:54:05 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:54:29 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:56:13 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:56:13 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:56:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:56:44 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:56:44 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 330
ERROR - 2015-10-02 12:57:10 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:57:10 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 315
ERROR - 2015-10-02 12:57:10 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 330
ERROR - 2015-10-02 12:59:00 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:59:00 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 12:59:00 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 12:59:00 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 333
ERROR - 2015-10-02 12:59:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:59:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 12:59:21 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 12:59:21 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 333
ERROR - 2015-10-02 12:59:57 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 12:59:57 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 12:59:57 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 12:59:57 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 333
ERROR - 2015-10-02 13:00:09 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 13:00:09 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 13:00:09 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 13:00:09 --> Severity: Notice --> Undefined variable: row /var/www/html/ci/application/controllers/B_up_xml_controller2.php 333
ERROR - 2015-10-02 13:00:54 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 13:00:54 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 13:00:54 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 13:01:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 13:01:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 300
ERROR - 2015-10-02 13:01:22 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 318
ERROR - 2015-10-02 13:08:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 297
ERROR - 2015-10-02 13:08:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 13:08:06 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 327
ERROR - 2015-10-02 13:10:57 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 13:10:57 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 327
ERROR - 2015-10-02 13:11:42 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 309
ERROR - 2015-10-02 13:11:42 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 327
ERROR - 2015-10-02 13:12:48 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 307
ERROR - 2015-10-02 13:12:48 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 13:12:48 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 328
ERROR - 2015-10-02 13:13:24 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 307
ERROR - 2015-10-02 13:13:24 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 13:13:24 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 328
ERROR - 2015-10-02 13:14:02 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 307
ERROR - 2015-10-02 13:14:02 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 13:14:02 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 328
ERROR - 2015-10-02 13:14:33 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 13:14:33 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 328
ERROR - 2015-10-02 13:17:30 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:17:30 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller2.php 314
ERROR - 2015-10-02 13:17:30 --> Severity: Notice --> Undefined variable: d_ant /var/www/html/ci/application/controllers/B_up_xml_controller2.php 332
ERROR - 2015-10-02 13:21:54 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:22:17 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:22:58 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:23:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:24:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:24:32 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:26:39 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller2.php 311
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-10-02 13:32:12 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-10-02 13:32:12 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-10-02 13:32:12 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-10-02 13:32:12 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-10-02 13:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller2.php 310
ERROR - 2015-10-02 13:47:29 --> Severity: Notice --> Undefined variable: value /var/www/html/ci/application/controllers/B_up_xml_controller2.php 331
ERROR - 2015-10-02 14:15:49 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 340
ERROR - 2015-10-02 14:16:42 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 341
ERROR - 2015-10-02 14:29:40 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller2.php 366
ERROR - 2015-10-02 14:59:46 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 323
ERROR - 2015-10-02 15:43:25 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 303
ERROR - 2015-10-02 18:56:58 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller2.php 345

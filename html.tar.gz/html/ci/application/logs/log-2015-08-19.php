<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-19 12:36:59 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 262
ERROR - 2015-08-19 15:21:45 --> Severity: Parsing Error --> syntax error, unexpected '$NOR041213MX4_Factura_XFA2747_' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 283
ERROR - 2015-08-19 15:22:08 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 283
ERROR - 2015-08-19 15:41:49 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 282
ERROR - 2015-08-19 16:07:08 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:07:30 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:08:03 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:08:32 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:08:45 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:13:46 --> Severity: Error --> Call to undefined function index() /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:14:11 --> Severity: Error --> Call to undefined function index() /var/www/html/ci/application/controllers/Up_xml_controller.php 165
ERROR - 2015-08-19 16:24:54 --> Severity: Parsing Error --> syntax error, unexpected '');' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ci/application/controllers/Up_xml_controller.php 263
ERROR - 2015-08-19 16:38:46 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/controllers/Up_xml_controller.php 347
ERROR - 2015-08-19 16:47:45 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 69
ERROR - 2015-08-19 16:57:42 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 74
ERROR - 2015-08-19 17:02:33 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/ci/application/views/up_xml_view.php 66
ERROR - 2015-08-19 17:04:15 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/ci/application/views/up_xml_view.php 66
ERROR - 2015-08-19 17:07:12 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/ci/application/views/up_xml_view.php 66
ERROR - 2015-08-19 17:07:23 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/ci/application/views/up_xml_view.php 66
ERROR - 2015-08-19 17:08:45 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) /var/www/html/ci/application/views/up_xml_view.php 66
ERROR - 2015-08-19 17:10:35 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 78
ERROR - 2015-08-19 17:13:57 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 77
ERROR - 2015-08-19 17:53:35 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/controllers/Up_xml_controller.php 180
ERROR - 2015-08-19 19:19:48 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 98
ERROR - 2015-08-19 19:20:13 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 99

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-18 11:24:42 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_view.php 30
ERROR - 2015-08-18 11:25:16 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 132
ERROR - 2015-08-18 11:25:56 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_view.php 132
ERROR - 2015-08-18 12:39:19 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 427
ERROR - 2015-08-18 12:51:08 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/views/up_xml_view.php 44
ERROR - 2015-08-18 12:54:05 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/views/up_xml_view.php 44
ERROR - 2015-08-18 12:54:17 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC), expecting ',' or ';' /var/www/html/ci/application/views/up_xml_view.php 44
ERROR - 2015-08-18 13:10:46 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 199
ERROR - 2015-08-18 13:32:15 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:32:40 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:32:44 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:32:59 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:33:37 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:33:41 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:34:19 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:34:23 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:34:31 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:34:50 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 201
ERROR - 2015-08-18 13:37:12 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 210
ERROR - 2015-08-18 13:39:42 --> Severity: Parsing Error --> syntax error, unexpected '$contenido_xml' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller.php 210
ERROR - 2015-08-18 13:39:52 --> Severity: Parsing Error --> syntax error, unexpected 'fclose' (T_STRING) /var/www/html/ci/application/controllers/Up_xml_controller.php 211
ERROR - 2015-08-18 15:20:59 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 220
ERROR - 2015-08-18 15:36:43 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 223
ERROR - 2015-08-18 16:02:47 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 234
ERROR - 2015-08-18 16:03:50 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 234
ERROR - 2015-08-18 16:05:36 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2rray.php:13) /var/www/html/ci/application/views/xml2rray.php 13
ERROR - 2015-08-18 16:06:44 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:07:53 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:34:40 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 235
ERROR - 2015-08-18 16:35:02 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 235
ERROR - 2015-08-18 16:35:07 --> Severity: Error --> Call to undefined function xml2array() /var/www/html/ci/application/controllers/Up_xml_controller.php 235
ERROR - 2015-08-18 16:35:27 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:36:00 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:37:13 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:38:01 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:39:02 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:39:20 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:40:10 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 16:43:45 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:03:39 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:05:16 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:05:36 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:06:27 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:06:47 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:07:35 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:08:25 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:09:04 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:10:50 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:14:19 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:16:38 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:21:16 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:44:22 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:44:54 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:47:52 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:48:29 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:48:32 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:49:03 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:49:28 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:49:55 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:50:16 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:51:13 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 17:51:46 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 18:05:02 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 18:14:02 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 18:14:39 --> Severity: Error --> Cannot redeclare xml2array() (previously declared in /var/www/html/ci/application/views/xml2array.php:13) /var/www/html/ci/application/views/xml2array.php 13
ERROR - 2015-08-18 19:02:18 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' /var/www/html/ci/application/controllers/Up_xml_controller.php 266

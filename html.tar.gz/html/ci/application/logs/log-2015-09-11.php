<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-11 11:23:51 --> Severity: Parsing Error --> syntax error, unexpected '$compara_result' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 237
ERROR - 2015-09-11 11:24:11 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 265
ERROR - 2015-09-11 11:25:06 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 113
ERROR - 2015-09-11 11:25:06 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-11 11:25:06 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-11 11:25:06 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 218
ERROR - 2015-09-11 11:25:06 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 237
ERROR - 2015-09-11 11:25:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-11 11:25:06 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 268
ERROR - 2015-09-11 11:25:07 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 72 bytes) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 785
ERROR - 2015-09-11 11:25:18 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-11 11:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 347
ERROR - 2015-09-11 11:25:18 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 450
ERROR - 2015-09-11 11:25:18 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 451
ERROR - 2015-09-11 11:25:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 452
ERROR - 2015-09-11 11:25:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-11 11:25:18 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:31:09 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-11 11:31:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-11 11:31:09 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-11 11:31:09 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-11 11:31:09 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-11 11:31:09 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-11 11:31:09 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:32:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-11 11:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 350
ERROR - 2015-09-11 11:32:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 453
ERROR - 2015-09-11 11:32:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 454
ERROR - 2015-09-11 11:32:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-11 11:32:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-11 11:32:05 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:34:14 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:34:14 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:34:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:34:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:34:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:34:14 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:40:07 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:40:07 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:40:07 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:40:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:40:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:40:07 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:41:08 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:41:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:41:08 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:41:08 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:41:08 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:41:08 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:41:08 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:43:24 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:43:24 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:43:24 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:43:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:43:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:43:24 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:43:54 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:43:54 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:43:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:43:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:43:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:43:54 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:44:21 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:44:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:44:21 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:44:21 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:44:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:44:21 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:44:21 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:46:57 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:46:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:46:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:46:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:46:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:46:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:46:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:47:04 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:47:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:47:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:47:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:47:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:47:04 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:47:10 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:47:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:47:10 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:47:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:47:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:47:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:47:10 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:56:24 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:56:24 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:56:24 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:56:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:56:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:56:24 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 11:56:36 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 11:56:36 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 11:56:36 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 11:56:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 11:56:36 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 11:56:36 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:02:32 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:02:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:02:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:02:32 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:02:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 12:02:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:02:32 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:05:32 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:05:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:05:32 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:05:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 12:05:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:05:32 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:06:53 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:06:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 354
ERROR - 2015-09-11 12:06:53 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:06:53 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:06:53 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 12:06:53 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:06:53 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:07:48 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-11 12:07:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-11 12:07:48 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-11 12:07:48 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-11 12:07:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:07:48 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:07:48 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:09:35 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-11 12:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 352
ERROR - 2015-09-11 12:09:35 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 455
ERROR - 2015-09-11 12:09:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-11 12:09:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:09:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:09:35 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:15:31 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-11 12:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 353
ERROR - 2015-09-11 12:15:31 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 456
ERROR - 2015-09-11 12:15:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 457
ERROR - 2015-09-11 12:15:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 458
ERROR - 2015-09-11 12:15:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 459
ERROR - 2015-09-11 12:15:31 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:16:50 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:16:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:16:50 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:16:50 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:16:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:16:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:16:50 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:16:59 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:16:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:16:59 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:16:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:16:59 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:17:05 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 357
ERROR - 2015-09-11 12:17:05 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 460
ERROR - 2015-09-11 12:17:05 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:17:05 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:17:05 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:17:05 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:24:57 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:24:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:24:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:24:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:24:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:24:57 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:25:54 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:25:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:25:54 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:25:54 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:25:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:25:54 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:25:54 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:27:10 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:27:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 358
ERROR - 2015-09-11 12:27:10 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 461
ERROR - 2015-09-11 12:27:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:27:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:27:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:27:10 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:29:22 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:29:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:29:22 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:29:22 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:29:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:29:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:29:22 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:29:31 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:29:31 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:29:31 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:29:31 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:29:31 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:29:31 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:34:34 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:34:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:34:34 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:34:34 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:34:34 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:34:34 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:34:34 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:41:12 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 293
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 113
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 218
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 237
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 240
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 515
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 515
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 524
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 528
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 530
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 530
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 528
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 570
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 570
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 612
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-11 12:41:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 624
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 638
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 641
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 642
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: calle /var/www/html/ci/application/controllers/B_up_xml_controller1.php 643
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: no_ext /var/www/html/ci/application/controllers/B_up_xml_controller1.php 644
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: no_int /var/www/html/ci/application/controllers/B_up_xml_controller1.php 645
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: colonia /var/www/html/ci/application/controllers/B_up_xml_controller1.php 646
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: referen /var/www/html/ci/application/controllers/B_up_xml_controller1.php 647
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: mun /var/www/html/ci/application/controllers/B_up_xml_controller1.php 648
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: estado /var/www/html/ci/application/controllers/B_up_xml_controller1.php 649
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: pais /var/www/html/ci/application/controllers/B_up_xml_controller1.php 650
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: cp /var/www/html/ci/application/controllers/B_up_xml_controller1.php 651
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 652
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 654
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: rfc_nom /var/www/html/ci/application/controllers/B_up_xml_controller1.php 655
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: fecha /var/www/html/ci/application/controllers/B_up_xml_controller1.php 656
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: subtotal /var/www/html/ci/application/controllers/B_up_xml_controller1.php 657
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: moneda /var/www/html/ci/application/controllers/B_up_xml_controller1.php 658
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: total /var/www/html/ci/application/controllers/B_up_xml_controller1.php 659
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: id_rfc /var/www/html/ci/application/controllers/B_up_xml_controller1.php 660
ERROR - 2015-09-11 12:41:30 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-11 12:41:35 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:41:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:41:35 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:41:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:41:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:41:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:41:35 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:41:45 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:41:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:41:45 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:41:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:41:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:41:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:41:45 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:42:59 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:42:59 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:42:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:42:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:42:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:42:59 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 12:43:24 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 12:43:24 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 12:43:24 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 12:43:24 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 12:43:24 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 12:43:24 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 13:19:06 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 13:19:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 359
ERROR - 2015-09-11 13:19:06 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 462
ERROR - 2015-09-11 13:19:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 463
ERROR - 2015-09-11 13:19:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 464
ERROR - 2015-09-11 13:19:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 13:19:06 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 13:59:27 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 362
ERROR - 2015-09-11 13:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 362
ERROR - 2015-09-11 13:59:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 465
ERROR - 2015-09-11 13:59:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 13:59:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 13:59:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 13:59:27 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 14:00:29 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:00:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:00:29 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 14:00:29 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 14:00:29 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 14:00:29 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 14:00:29 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 14:00:41 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:00:41 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 14:00:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 14:00:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 14:00:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 14:00:41 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 14:04:13 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 14:04:13 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 14:04:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 14:04:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 14:04:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 14:04:13 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:10:35 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined variable: key /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined variable: key /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:13:26 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined variable: key /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined variable: key /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:13:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:13:26 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:14:06 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:15:22 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:15:22 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:15:22 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:16:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:16:59 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:16:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:16:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:16:59 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:18:45 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:18:45 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:20:41 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:20:41 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:23:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:23:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:26:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:26:23 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:28:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:28:18 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::asignando_variables_XML2(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 271 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 505
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:35:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:35:13 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:37:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:37:20 --> Severity: Warning --> Cannot use a scalar value as an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 666
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:38:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 547
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:40:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:40:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 534
ERROR - 2015-09-11 14:45:30 --> Severity: Parsing Error --> syntax error, unexpected '$cont' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:45:59 --> Severity: Parsing Error --> syntax error, unexpected '$cont' (T_VARIABLE) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:47:46 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 523
ERROR - 2015-09-11 14:48:11 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:48:11 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:48:11 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:52:07 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:52:07 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:52:07 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:53:21 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:53:21 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:53:21 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:54:04 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:54:04 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:54:04 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:55:05 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:55:05 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:55:05 --> Severity: Warning --> implode(): Argument must be an array /var/www/html/ci/application/controllers/B_up_xml_controller1.php 520
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: cont /var/www/html/ci/application/controllers/B_up_xml_controller1.php 521
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 548
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:55:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 535
ERROR - 2015-09-11 14:55:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 535
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:58:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 14:58:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 14:59:27 --> Severity: Parsing Error --> syntax error, unexpected '$value' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 14:59:43 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 14:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:00:25 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:16:10 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 525
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 8
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 31
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-11 15:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:30:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso2_view.php 8
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 21
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 31
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-11 15:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 43
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:36:20 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:40:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 20
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 30
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-11 15:40:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 42
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:40:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:40:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:43:07 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:43:07 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/views/b_xmlcaso2_view.php 183
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-11 15:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 13
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 25
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 15:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 15:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:44:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 14
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 18
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: i /var/www/html/ci/application/views/b_xmlcaso2_view.php 18
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 28
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 39
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 51
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-11 15:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 59
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:51:16 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:52:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 14
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 18
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 38
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:52:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-11 15:52:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:52:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:52:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 14
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view.php 18
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 27
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 38
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:52:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 50
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-11 15:52:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 58
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 802
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 803
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 804
ERROR - 2015-09-11 15:52:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 805
ERROR - 2015-09-11 16:20:21 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/ci/application/views/b_xmlcaso2_view.php 18
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 830
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 831
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 832
ERROR - 2015-09-11 16:39:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 833
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 830
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 831
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 832
ERROR - 2015-09-11 16:40:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 833
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:41:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 23
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 35
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:41:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 47
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:41:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 55
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 830
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 831
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 832
ERROR - 2015-09-11 16:41:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 833
ERROR - 2015-09-11 16:46:42 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 721
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 16:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 834
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 835
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 836
ERROR - 2015-09-11 16:53:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 837
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:56:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 16:56:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 16:56:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 834
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 835
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 836
ERROR - 2015-09-11 16:56:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 837
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:00:44 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:00:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:03:16 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:04:04 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:04:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 686
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:05:35 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:19:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 662
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:20:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:20:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:20:02 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:20:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:20:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:20:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:20:56 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:20:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 536
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 560
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 562
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 564
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 564
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 571
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 573
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 577
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 579
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 583
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 702
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:21:28 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:22:16 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:22:16 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 17:22:16 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 17:22:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 17:22:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 17:22:16 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 17:23:38 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:23:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:23:38 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 17:23:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 17:23:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 17:23:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 17:23:38 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 17:23:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-11 17:24:50 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:24:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:24:50 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 17:24:50 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 17:24:50 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 17:24:50 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 17:24:50 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 17:24:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 549
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 550
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 551
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 688
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 12
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 24
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 36
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: datos_concepto_descrip /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 48
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined variable: datos_concepto_cantidad /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/b_xmlcaso2_view.php 56
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 836
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 837
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 838
ERROR - 2015-09-11 17:26:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 839
ERROR - 2015-09-11 17:43:59 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 363
ERROR - 2015-09-11 17:43:59 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 466
ERROR - 2015-09-11 17:43:59 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 17:43:59 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 17:43:59 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 17:43:59 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 17:43:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-11 18:07:07 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 364
ERROR - 2015-09-11 18:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 364
ERROR - 2015-09-11 18:07:07 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 18:07:07 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 18:07:07 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 18:07:07 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 470
ERROR - 2015-09-11 18:07:07 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 18:07:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-11 18:12:32 --> Severity: Notice --> Undefined index: attr /var/www/html/ci/application/controllers/B_up_xml_controller1.php 364
ERROR - 2015-09-11 18:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 364
ERROR - 2015-09-11 18:12:32 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 467
ERROR - 2015-09-11 18:12:32 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 468
ERROR - 2015-09-11 18:12:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 469
ERROR - 2015-09-11 18:12:32 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 470
ERROR - 2015-09-11 18:12:32 --> Query error: Column 'cantidad' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', NULL, NULL, NULL, NULL)
ERROR - 2015-09-11 18:12:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-11 18:51:03 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 235
ERROR - 2015-09-11 19:15:19 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 286
ERROR - 2015-09-11 19:15:39 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 434
ERROR - 2015-09-11 19:21:40 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 158
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined variable: i /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined index:  /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-11 19:24:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 232
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 335
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 336
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 337
ERROR - 2015-09-11 19:24:38 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 338
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 227
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined variable: i /var/www/html/ci/application/controllers/B_up_xml_controller1.php 235
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined index:  /var/www/html/ci/application/controllers/B_up_xml_controller1.php 235
ERROR - 2015-09-11 19:26:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 235
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 338
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 339
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 340
ERROR - 2015-09-11 19:26:57 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 341
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined offset: 0 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 175
ERROR - 2015-09-11 19:36:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 175
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined offset: 1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 175
ERROR - 2015-09-11 19:36:27 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 175
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 278
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 280
ERROR - 2015-09-11 19:36:27 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 281
ERROR - 2015-09-11 19:43:21 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 19:47:40 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:08:16 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 189
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/controllers/B_up_xml_controller1.php 190
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191
ERROR - 2015-09-11 20:10:56 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/controllers/B_up_xml_controller1.php 191

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> readfile(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 112
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> filesize(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/controllers/D_new_controller.php 114
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> fopen(/root/CertificadosUnion1/archivo.php): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 117
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente36Pba1.conf): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 120
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/caPba1.crt): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 129
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/CertificadoCERT.cert): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 139
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> file_get_contents(/root/CertificadosUnion1/cliente27Pba1.key): failed to open stream: No such file or directory /var/www/html/ci/application/controllers/D_new_controller.php 149
ERROR - 2015-08-25 09:50:39 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/html/ci/application/views/d_new_view.php 20
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/ci/application/views/d_new_view.php 80
ERROR - 2015-08-25 09:50:39 --> Severity: Notice --> Undefined variable: info_hay /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-25 09:50:39 --> Severity: Notice --> Undefined variable: info_value /var/www/html/ci/application/views/d_new_view.php 171
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 175
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> fileperms(): stat failed for /root/CertificadosUnion1/archivo.php /var/www/html/ci/application/views/d_new_view.php 177
ERROR - 2015-08-25 09:50:39 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /var/www/html/ci/application/controllers/D_new_controller.php 169
ERROR - 2015-08-25 10:52:24 --> Severity: Error --> Call to undefined function br() /var/www/html/ci/application/views/up_xml_in_view1.php 11
ERROR - 2015-08-25 10:53:18 --> Severity: Error --> Call to undefined function br() /var/www/html/ci/application/views/up_xml_in_view1.php 11
ERROR - 2015-08-25 10:53:41 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 11
ERROR - 2015-08-25 10:55:22 --> Severity: Error --> Call to undefined function br() /var/www/html/ci/application/views/up_xml_in_view1.php 11
ERROR - 2015-08-25 10:55:49 --> Severity: Error --> Call to undefined function br() /var/www/html/ci/application/views/up_xml_in_view1.php 11
ERROR - 2015-08-25 11:25:21 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC) /var/www/html/ci/application/views/up_xml_in_view1.php 57
ERROR - 2015-08-25 11:25:36 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC) /var/www/html/ci/application/views/up_xml_in_view1.php 57
ERROR - 2015-08-25 11:33:55 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 15
ERROR - 2015-08-25 11:34:28 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 15
ERROR - 2015-08-25 11:34:52 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 15
ERROR - 2015-08-25 11:36:04 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/up_xml_in_view1.php 15
ERROR - 2015-08-25 11:54:13 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/html/ci/application/views/up_xml_in_view1.php 27
ERROR - 2015-08-25 11:55:01 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 27
ERROR - 2015-08-25 11:55:36 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 27
ERROR - 2015-08-25 11:55:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/ci/application/views/up_xml_in_view1.php 26
ERROR - 2015-08-25 11:58:08 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 133431296 bytes) /var/www/html/ci/application/views/up_xml_in_view1.php 27
ERROR - 2015-08-25 11:59:39 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_in_view1.php 88
ERROR - 2015-08-25 12:04:14 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/views/up_xml_in_view1.php 89
ERROR - 2015-08-25 12:22:39 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/views/up_xml_in_view1.php 89
ERROR - 2015-08-25 12:30:46 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_in_view1.php 32
ERROR - 2015-08-25 12:30:58 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_in_view1.php 91
ERROR - 2015-08-25 12:38:39 --> Severity: Parsing Error --> syntax error, unexpected '>' /var/www/html/ci/application/views/up_xml_in_view1.php 9
ERROR - 2015-08-25 12:39:53 --> Severity: Parsing Error --> syntax error, unexpected '400' (T_LNUMBER) /var/www/html/ci/application/views/up_xml_in_view1.php 9
ERROR - 2015-08-25 12:41:17 --> Severity: Parsing Error --> syntax error, unexpected '400' (T_LNUMBER) /var/www/html/ci/application/views/up_xml_in_view1.php 9
ERROR - 2015-08-25 12:59:10 --> Severity: Parsing Error --> syntax error, unexpected 'WIDTH' (T_STRING) /var/www/html/ci/application/views/up_xml_in_view1.php 32
ERROR - 2015-08-25 13:01:56 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/ci/application/views/up_xml_in_view1.php 97
ERROR - 2015-08-25 13:11:42 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_in_view1.php 96
ERROR - 2015-08-25 14:51:49 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/views/up_xml_in_view1a.php 99
ERROR - 2015-08-25 20:23:59 --> Severity: Error --> Call to a member function insert() on null /var/www/html/ci/application/controllers/Up_xml_controller1.php 134
ERROR - 2015-08-25 20:36:14 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/ci/application/controllers/Up_xml_controller1.php 135

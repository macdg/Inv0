<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-08 09:43:02 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 09:43:02 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 09:43:02 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 09:43:07 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::seleccionando_opcion_xml(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 178 and defined /var/www/html/ci/application/controllers/B_up_xml_controller1.php 183
ERROR - 2015-09-08 09:43:07 --> Severity: Notice --> Undefined variable: dato_check /var/www/html/ci/application/controllers/B_up_xml_controller1.php 196
ERROR - 2015-09-08 09:44:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 09:44:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 09:44:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 09:47:46 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 09:47:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 09:47:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:25:48 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:25:48 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:25:48 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:26:13 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:26:13 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:26:13 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:28:45 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:28:45 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:28:45 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:45:14 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:45:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:45:14 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:45:44 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:45:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:45:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:47:49 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:47:49 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:47:49 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:54:44 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:54:44 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:54:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 10:58:32 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 44
ERROR - 2015-09-08 10:58:32 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 45
ERROR - 2015-09-08 10:58:32 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 46
ERROR - 2015-09-08 11:00:21 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 49
ERROR - 2015-09-08 11:00:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 50
ERROR - 2015-09-08 11:00:21 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:01:16 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 49
ERROR - 2015-09-08 11:01:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 50
ERROR - 2015-09-08 11:01:16 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:05:42 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 49
ERROR - 2015-09-08 11:05:42 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 50
ERROR - 2015-09-08 11:05:42 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:15:17 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/ci/application/views/b_subirgeneral1_view.php 24
ERROR - 2015-09-08 11:16:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/ci/application/views/b_subirgeneral1_view.php 24
ERROR - 2015-09-08 11:18:52 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:18:52 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:18:52 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:19:41 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:19:41 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:19:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:20:30 --> Severity: Notice --> Undefined variable: oculto /var/www/html/ci/application/views/b_subirgeneral1_view.php 25
ERROR - 2015-09-08 11:20:30 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:20:30 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:20:30 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:21:04 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:21:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:21:04 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:22:28 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:22:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:22:28 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:23:14 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:23:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:23:14 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:24:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:24:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:24:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:25:20 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:25:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:25:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 11:35:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 11:35:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 11:35:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:02:54 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:02:54 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:02:54 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:02:57 --> Severity: Notice --> Undefined variable: contents /var/www/html/ci/application/controllers/B_up_xml_controller1.php 73
ERROR - 2015-09-08 12:02:57 --> Severity: Notice --> Undefined variable: result /var/www/html/ci/application/controllers/B_up_xml_controller1.php 73
ERROR - 2015-09-08 12:02:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/application/controllers/B_up_xml_controller1.php:246) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-08 12:02:57 --> Severity: Error --> Call to undefined function seleccionando_opcion_xml() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 246
ERROR - 2015-09-08 12:11:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 242
ERROR - 2015-09-08 12:16:08 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 297
ERROR - 2015-09-08 12:16:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:16:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:16:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:16:41 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 279
ERROR - 2015-09-08 12:21:16 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:21:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:21:16 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:46 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:21:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:21:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:21:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:47 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:22:47 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:22:47 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:22:50 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:16 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:24:16 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:24:16 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:24:57 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:24:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:24:57 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:00 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:25:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:25:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:25:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:38 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:35:38 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:35:38 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:35:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 270
ERROR - 2015-09-08 12:37:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:37:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:37:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:37:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 271
ERROR - 2015-09-08 12:39:28 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:39:28 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:39:28 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:39:31 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:19 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:40:19 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:40:19 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:40:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:40 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:41:40 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:41:40 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:41:44 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:43 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:42:43 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:42:43 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:42:46 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 273
ERROR - 2015-09-08 12:43:55 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:43:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:43:55 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:43:58 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 275
ERROR - 2015-09-08 12:45:21 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 12:45:21 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 12:45:21 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 12:45:25 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:01 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:01:01 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:01:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:05 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:55 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:01:55 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:01:55 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:01:59 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:13:57 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:13:57 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:13:57 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:01 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:11 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:14:11 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:14:11 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:14:15 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:20 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:15:20 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:15:20 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:15:24 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/controllers/B_up_xml_controller1.php 284
ERROR - 2015-09-08 13:20:23 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_subirgeneral1_view.php 51
ERROR - 2015-09-08 13:20:23 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_subirgeneral1_view.php 52
ERROR - 2015-09-08 13:20:23 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_subirgeneral1_view.php 53
ERROR - 2015-09-08 13:48:26 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:48:43 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:48:58 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:50:25 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:51:23 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:53:35 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:55:25 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:55:42 --> Severity: Parsing Error --> syntax error, unexpected 'b_up_xml_controller1' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:56:02 --> Severity: Parsing Error --> syntax error, unexpected '')'' (T_CONSTANT_ENCAPSED_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 34
ERROR - 2015-09-08 13:57:34 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 36
ERROR - 2015-09-08 13:57:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/ci/application/views/b_subirgeneral1_view.php 36
ERROR - 2015-09-08 13:58:41 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 36
ERROR - 2015-09-08 13:59:12 --> Severity: Parsing Error --> syntax error, unexpected 'index' (T_STRING) /var/www/html/ci/application/views/b_subirgeneral1_view.php 36
ERROR - 2015-09-08 14:13:46 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/ci/application/views/b_subirgeneral1_view.php 38
ERROR - 2015-09-08 15:07:34 --> Severity: Warning --> Illegal string offset 'total' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 369
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 23
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-08 15:45:37 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-08 15:46:30 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-08 15:46:30 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-08 15:46:30 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-08 15:46:30 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-08 15:46:30 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-08 15:47:36 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-08 15:47:36 --> Severity: Notice --> Undefined variable: uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 11
ERROR - 2015-09-08 15:47:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 17
ERROR - 2015-09-08 15:47:36 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-08 15:47:36 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-08 15:50:24 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-08 15:50:24 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-08 15:50:24 --> Severity: Notice --> Undefined variable: cant /var/www/html/ci/application/views/b_xmlcaso1_view.php 45
ERROR - 2015-09-08 15:52:20 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 7
ERROR - 2015-09-08 15:52:20 --> Severity: Notice --> Use of undefined constant php - assumed 'php' /var/www/html/ci/application/views/b_xmlcaso1_view.php 30
ERROR - 2015-09-08 16:07:38 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/ci/application/views/b_xmlcaso1_view.php 162
ERROR - 2015-09-08 17:41:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/views/b_xmlcaso1_view.php 52
ERROR - 2015-09-08 17:45:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/views/b_xmlcaso1_view.php 52
ERROR - 2015-09-08 17:47:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/views/b_xmlcaso1_view.php 47
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Missing argument 2 for Up_xml_model::concepto_data_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 409 and defined /var/www/html/ci/application/models/Up_xml_model.php 12
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Missing argument 3 for Up_xml_model::concepto_data_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 409 and defined /var/www/html/ci/application/models/Up_xml_model.php 12
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Missing argument 4 for Up_xml_model::concepto_data_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 409 and defined /var/www/html/ci/application/models/Up_xml_model.php 12
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Missing argument 5 for Up_xml_model::concepto_data_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 409 and defined /var/www/html/ci/application/models/Up_xml_model.php 12
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Missing argument 6 for Up_xml_model::concepto_data_insert(), called in /var/www/html/ci/application/controllers/B_up_xml_controller1.php on line 409 and defined /var/www/html/ci/application/models/Up_xml_model.php 12
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/models/Up_xml_model.php 16
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: unidad /var/www/html/ci/application/models/Up_xml_model.php 17
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: no_ident /var/www/html/ci/application/models/Up_xml_model.php 18
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/models/Up_xml_model.php 19
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Undefined variable: val_unit /var/www/html/ci/application/models/Up_xml_model.php 21
ERROR - 2015-09-08 18:29:14 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/database/DB_driver.php 1392
ERROR - 2015-09-08 18:29:14 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `no_ident`, `descrip`, `val_unit`) VALUES (Array, NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-08 18:29:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/ci/system/core/Exceptions.php:272) /var/www/html/ci/system/core/Common.php 569
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 411
ERROR - 2015-09-08 18:36:57 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 18:45:16 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 18:45:16 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 18:48:35 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 18:48:35 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 18:50:59 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 167
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 171
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 18:56:20 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 175
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 168
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 172
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 18:58:20 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 176
ERROR - 2015-09-08 18:59:44 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 18:59:44 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 18:59:44 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:00:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:02:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:02:13 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:02:13 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:05:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:07:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:09:50 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:10:22 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:12:49 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:13:08 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:13:26 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-08 19:13:26 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-08 19:13:26 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 399
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 403
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:13:26 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:15:13 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:15:33 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:15:33 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:15:33 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Undefined variable: oculto_a /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Undefined variable: oculto_b /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Undefined variable: oculto_c /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 412
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-08 19:15:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 418
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:18:11 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/views/b_xmlcaso1_view.php 166
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/views/b_xmlcaso1_view.php 170
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/views/b_xmlcaso1_view.php 174
ERROR - 2015-09-08 19:20:55 --> Severity: Notice --> Array to string conversion /var/www/html/ci/system/helpers/form_helper.php 103
ERROR - 2015-09-08 19:21:38 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:21:38 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:21:38 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 412
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-08 19:21:38 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 418
ERROR - 2015-09-08 19:23:41 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:23:41 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:23:41 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 401
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 404
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 409
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 412
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-08 19:23:41 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 418
ERROR - 2015-09-08 19:27:01 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-08 19:27:01 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:27:01 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:27:01 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:27:01 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:28:33 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:28:33 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:28:33 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 405
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 406
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 407
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:28:33 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:30:02 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 408
ERROR - 2015-09-08 19:30:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:30:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:30:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:30:02 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-08 19:36:10 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-08 19:36:57 --> Severity: Warning --> Missing argument 1 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:36:57 --> Severity: Warning --> Missing argument 2 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:36:57 --> Severity: Warning --> Missing argument 3 for B_up_xml_controller1::send_from_data_model() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 402
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 410
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 411
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_concepto /var/www/html/ci/application/controllers/B_up_xml_controller1.php 412
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 414
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_proveedor /var/www/html/ci/application/controllers/B_up_xml_controller1.php 415
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 417
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_factura /var/www/html/ci/application/controllers/B_up_xml_controller1.php 418
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 420
ERROR - 2015-09-08 19:36:57 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 421
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 19
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 52
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 423
ERROR - 2015-09-08 19:59:46 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 424
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 19
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 52
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 413
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 416
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Array to string conversion /var/www/html/ci/application/controllers/B_up_xml_controller1.php 419
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 422
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 423
ERROR - 2015-09-08 20:00:04 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 424
ERROR - 2015-09-08 20:09:03 --> Severity: Parsing Error --> syntax error, unexpected '$datos_productos' (T_VARIABLE), expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-08 20:10:27 --> Severity: Parsing Error --> syntax error, unexpected '$datos_productos' (T_VARIABLE), expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-08 20:10:43 --> Severity: Parsing Error --> syntax error, unexpected '$datos_productos' (T_VARIABLE), expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-08 20:12:42 --> Severity: Parsing Error --> syntax error, unexpected '$datos_productos' (T_VARIABLE), expecting '(' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 397
ERROR - 2015-09-08 20:14:36 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-08 20:14:36 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 12
ERROR - 2015-09-08 20:14:36 --> Severity: Notice --> Undefined variable: id_uuid /var/www/html/ci/application/views/b_xmlcaso1_view.php 19
ERROR - 2015-09-08 20:14:36 --> Severity: Notice --> Undefined variable: descrip /var/www/html/ci/application/views/b_xmlcaso1_view.php 26
ERROR - 2015-09-08 20:14:36 --> Severity: Notice --> Undefined variable: cantidad /var/www/html/ci/application/views/b_xmlcaso1_view.php 52
ERROR - 2015-09-08 20:16:03 --> Severity: Notice --> Undefined variable: datos_in_cantidad /var/www/html/ci/application/controllers/B_up_xml_controller1.php 395
ERROR - 2015-09-08 20:19:27 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 397
ERROR - 2015-09-08 20:30:49 --> Severity: Notice --> Undefined variable: datos_productos /var/www/html/ci/application/controllers/B_up_xml_controller1.php 397

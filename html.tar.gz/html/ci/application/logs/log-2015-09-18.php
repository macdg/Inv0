<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-18 09:55:15 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 567
ERROR - 2015-09-18 10:22:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 636
ERROR - 2015-09-18 11:20:32 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 747
ERROR - 2015-09-18 11:21:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/B_up_xml_controller1.php 636
ERROR - 2015-09-18 11:22:55 --> Severity: Notice --> Undefined index: mi_archivo_1 /var/www/html/ci/application/controllers/B_up_xml_controller1.php 39
ERROR - 2015-09-18 11:22:55 --> Severity: Notice --> Undefined variable: nombreFichero /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-18 11:22:55 --> Severity: Notice --> Undefined variable: rutaCompleta /var/www/html/ci/application/controllers/B_up_xml_controller1.php 85
ERROR - 2015-09-18 11:22:55 --> Severity: Warning --> file_get_contents(): Filename cannot be empty /var/www/html/ci/application/controllers/B_up_xml_controller1.php 131
ERROR - 2015-09-18 11:22:55 --> Severity: Notice --> Undefined index: cfdi:Comprobante /var/www/html/ci/application/controllers/B_up_xml_controller1.php 150
ERROR - 2015-09-18 12:25:48 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 566
ERROR - 2015-09-18 12:26:22 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 566
ERROR - 2015-09-18 12:36:04 --> Severity: Parsing Error --> syntax error, unexpected '$datos_concepto' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 589
ERROR - 2015-09-18 12:44:29 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 608
ERROR - 2015-09-18 12:49:23 --> Query error: Column 'id_uuid' cannot be null - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES (NULL, NULL, NULL, NULL, NULL)
ERROR - 2015-09-18 12:51:21 --> Query error: Duplicate entry '0-32f7865e-5ee9-46b0-857d-30cc9b7d68b5' for key 'id_concepto' - Invalid query: INSERT INTO `concepto` (`id_uuid`, `cantidad`, `unidad`, `descrip`, `val_unit`) VALUES ('32f7865e-5ee9-46b0-857d-30cc9b7d68b5', '3', 'pz', 'BALUN NEO BNC FEMALE TO RJ45 CCITT G703', '45.0000')
ERROR - 2015-09-18 14:00:38 --> Query error: Not unique table/alias: 'concepto' - Invalid query: SELECT `id_concepto`, `id_uuid`
FROM `concepto`, `concepto`
ERROR - 2015-09-18 14:01:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:01:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:02:03 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:02:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:02:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:02:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:03:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:03:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:03:57 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 14:03:58 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 575
ERROR - 2015-09-18 15:29:34 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-18 15:30:01 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-18 15:30:01 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-18 15:36:53 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:36:53 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:41:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:41:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:43:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:43:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:51:00 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 15:51:00 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 578
ERROR - 2015-09-18 16:09:05 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-18 16:09:05 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 580
ERROR - 2015-09-18 16:10:18 --> Severity: Parsing Error --> syntax error, unexpected '$igual' (T_VARIABLE), expecting ',' or ';' /var/www/html/ci/application/controllers/B_up_xml_controller1.php 572
ERROR - 2015-09-18 16:22:53 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-18 16:22:53 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 581
ERROR - 2015-09-18 17:33:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 593
ERROR - 2015-09-18 17:33:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /var/www/html/ci/application/controllers/B_up_xml_controller1.php 593
ERROR - 2015-09-18 18:21:36 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::resultado() /var/www/html/ci/application/controllers/B_up_xml_controller1.php 585

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-06 12:19:10 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 12:19:10 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 12:19:10 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 13:12:20 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 13:12:20 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 13:12:20 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 14:38:22 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 14:38:22 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 14:38:22 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 16:29:57 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 16:29:57 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 16:29:57 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 16:35:22 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 16:35:22 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 16:35:22 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:14:27 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 18:14:27 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:14:27 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:14:47 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 18:14:47 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:14:47 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:16:25 --> Severity: Notice --> Undefined variable: string_fichero4 /var/www/ci/application/views/d_new_view.php 20
ERROR - 2015-08-06 18:16:25 --> Severity: Notice --> Undefined variable: info_hay /var/www/ci/application/views/d_new_view.php 171
ERROR - 2015-08-06 18:16:25 --> Severity: Notice --> Undefined variable: info_value /var/www/ci/application/views/d_new_view.php 171

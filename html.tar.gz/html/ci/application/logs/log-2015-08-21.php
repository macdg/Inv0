<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-08-21 13:07:32 --> Severity: Parsing Error --> syntax error, unexpected '' $value: '' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 194
ERROR - 2015-08-21 13:08:21 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 195
ERROR - 2015-08-21 13:09:00 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 294
ERROR - 2015-08-21 13:18:22 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 197
ERROR - 2015-08-21 13:45:11 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 207
ERROR - 2015-08-21 13:45:39 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 207
ERROR - 2015-08-21 13:45:45 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 207
ERROR - 2015-08-21 14:13:09 --> Severity: Compile Error --> Call-time pass-by-reference has been removed /var/www/html/ci/application/controllers/Up_xml_controller.php 205
ERROR - 2015-08-21 15:33:55 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 270
ERROR - 2015-08-21 16:09:59 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting while (T_WHILE) /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-21 16:10:21 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting while (T_WHILE) /var/www/html/ci/application/controllers/Up_xml_controller.php 196
ERROR - 2015-08-21 16:11:00 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting while (T_WHILE) /var/www/html/ci/application/controllers/Up_xml_controller.php 198
ERROR - 2015-08-21 16:58:46 --> Severity: Error --> Maximum execution time of 200 seconds exceeded /var/www/html/ci/system/core/Common.php 612
ERROR - 2015-08-21 17:12:27 --> Severity: Error --> Maximum execution time of 200 seconds exceeded /var/www/html/ci/system/core/Common.php 595
ERROR - 2015-08-21 17:34:19 --> Severity: Parsing Error --> syntax error, unexpected '$', expecting ',' or ';' /var/www/html/ci/application/controllers/Up_xml_controller.php 208
ERROR - 2015-08-21 17:34:36 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER), expecting variable (T_VARIABLE) or '$' /var/www/html/ci/application/controllers/Up_xml_controller.php 208
ERROR - 2015-08-21 17:34:56 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting variable (T_VARIABLE) or '$' /var/www/html/ci/application/controllers/Up_xml_controller.php 208
ERROR - 2015-08-21 18:04:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' /var/www/html/ci/application/controllers/Up_xml_controller.php 227
ERROR - 2015-08-21 19:10:11 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:10:32 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 222
ERROR - 2015-08-21 19:11:27 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:14:55 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:15:00 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:15:47 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:16:10 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:16:23 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:16:45 --> Severity: Parsing Error --> syntax error, unexpected '$array' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/ci/application/controllers/Up_xml_controller.php 297
ERROR - 2015-08-21 19:44:01 --> Severity: Parsing Error --> syntax error, unexpected '.' /var/www/html/ci/application/controllers/Up_xml_controller1.php 188
ERROR - 2015-08-21 20:13:03 --> Severity: Parsing Error --> syntax error, unexpected '$si_existe_key' (T_VARIABLE) /var/www/html/ci/application/controllers/Up_xml_controller1.php 189

<?php
$this->load->helper('html');
$this->load->helper('form');
$this->load->model('B_up_xml_model','b_up_xml_model');
echo br(2);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo heading('XML1', 2);
?>

<TABLE BORDER=1 WIDTH="600">
<TR>
<TD WIDTH="300">Cantidad:     <?php echo $cantidad; ?></TD>
</TR>
</TABLE>

<TABLE BORDER=1 WIDTH="600">
<TR>
<TD WIDTH="400">UUID:  <?php echo $id_uuid; ?></TD>
</TR>
</TABLE>

<TABLE BORDER=1 WIDTH="600">
<TR>
<TD WIDTH="400">Descripción:<br><?php echo $descrip; ?>
</TD>
</TR>
</TABLE>
<BR><BR><HR>

<?php

echo form_open_multipart('index.php/b_up_xml_controller1/solicitar1');

//+++++++La linea de form_open_multipart se repite por que existe el for y el boton submit lo requiere.
//echo heading('Ingresar Productos', 2);
//echo br(1).'LINEA DE PRODUCTO<hr>';
  for ($k=0; $k<$cantidad; $k++){
//echo heading('Ingresar Productos', 2);
//echo br(1).'LINEA DE PRODUCTO<hr>';

echo form_open_multipart('solicitar1');
//http://localhost/ci/index.php/pagina_exito.php
echo form_label('Ingrese Cantidad: ', 'cantidad');
 $datos_in_cantidad = array(
              'name'        => 'cantidad',
              'id'          => 'cantidad',
              'value'       => '1',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:30',
            );
echo form_input($datos_in_cantidad);
echo br(1);

echo form_label('Ingrese Unidad: ', 'unidad');
 $datos_in_unidad = array(
              'name'        => 'unidad',
              'id'          => 'unidad',
              'value'       => '',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:90',
            );
echo form_input($datos_in_unidad);
echo br(1);

echo form_label('Ingrese Modelo: ', 'modelo');
 $datos_in_modelo = array(
              'name'        => 'modelo',
              'id'          => 'modelo',
              'value'       => '',
              'maxlength'   => '',
              'size'        => '',
              'style'       => 'width:187',
            );
echo form_input($datos_in_modelo);
echo br(1);

echo form_label('Ingrese Descripción: ', 'descripcion');
$datos_in_descripcion = array(
             'name'        => 'descripcion',
             'id'          => 'descripcion',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:48%',
           );
echo form_input($datos_in_descripcion);
echo br(1);

echo form_label('Ingrese Valor Unitario: ', 'valorunitario');
$datos_in_valorunitario = array(
             'name'        => 'valorunitario',
             'id'          => 'valorunitario',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:10%',
           );

echo form_input($datos_in_valorunitario);
echo br(1);

echo form_label('Ingrese Fecha de Ingreso: ', 'fecha');
$datos_in_fecha = array(
             'name'        => 'fecha_ingreso',
             'id'          => 'fecha_ingreso',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:20%',
           );

echo form_input($datos_in_fecha);
echo br(1);

echo form_label('Ingrese Número de Serie: ', 'numserie');
$datos_in_numserie = array(
             'name'        => 'noserie',
             'id'          => 'noserie',
             'value'       => '',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:100',
           );

echo form_input($datos_in_numserie);
echo br(1);

echo form_label('Ingrese Número de Pieza: ', 'pza');
$datos_in_pza = array(
             'name'        => 'nopieza',
             'id'          => 'nopieza',
             'value'       => '1',
             'maxlength'   => '',
             'size'        => '',
             'style'       => 'width:30',
           );

echo form_input($datos_in_pza);
echo br(1);
}
?>
<CENTER>
<?php

//$this->up_xml_model->productos_data_insert();
echo form_submit('Aceptar', 'Aceptar').form_reset('Reset', 'Reset');
?>
<form name="buttonbar">
<input type="button" value="Regresar" onClick="history.back()">
</form>
</CENTER>
<?php
//$this->up_xml_model->productos_data_insert();
$this->output->enable_profiler(TRUE);

//echo '<br>Registro: '.$k.'  de: '.$value;
echo br(3);
echo form_close();

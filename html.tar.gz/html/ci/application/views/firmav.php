<!DOCTYPE html>
<html>
<head>
	<title>Firma Vista Formulario de Carga</title>
</head>
<body>
<br>

<?php if (isset($error)) {
	echo '$error';

}?>

<article class="contenido">
<form action=" <?php echo base_url('firma_c/firmav');?>" method="post" enctype="multipart/form-data">
<label for="userfile">Archivo</label>
<input type="file" name="userfile" id="userfile" size="20">
<br>
<input type="submit" value="Eviar Archivo">
</article>

</body>
</html>
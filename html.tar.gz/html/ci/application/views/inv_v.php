<!DOCTYPE html>
<html>
<head>
	<title>Vista de Inv</title>
</head>
<body>

<!-- <form action="<?php// echo 'Inv_c.php';?>" method="post" enctype="multipart/form-data">
	<input type="file" name="num_mi_fila1" id="num_mi_fila1" size="20">
	<input type="file" name="num_mi_fila2" id="num_mi_fila2" size="20">
	<br>
	<input type="submit" value="Generar Llave" name="submit">
	<br><br>
</form>
 --><!-- ************************************************ -->
<br></hr>
<!-- <form name="form" action="Inv_c.php" method="post"> -->
<table width="600" align="center">

<td align="center" width ="800" valign="top" colspan="2">
<h2>Creando Área de Captura</h2>
</td>
</tr>

<tr>
<td valign="top" align="right">
Cuantos Filas a crear:
</td>
<td valign="top" align="left">
<input type="text" name="num" />
</td>
</tr>
</form>

+++++++++++++++++++++++++++++++++++++++++
<!-- <form action="<?php //echo 'D_new_controller';?>" method="post" enctype="multipart/form-data">
	<input type="file" name="mi_archivo_1" id="m_archivo_1" size="20">
	<input type="file" name="mi_archivo_2" id="m_archivo_2" size="20">
	<br>
	<input type="submit" value="Generar Llave" name="submit">
	<br><br>
</form>
 -->
+++++++++++++++++++++++++++++++++++++++++


<form name="form" action="<?php echo 'Inv_c';?>" method="post" enctype="multipart/form-data">
<tr>
<td valign="top" width="100" align="center" colspan="2">
<input type="button" value="Crear Fila" title="Crear Fila" id="num_mi_fila1" onclick="validar();" />
<?php //echo 'Inv_c.php';?>
</td>
</tr>
</form>
<!-- ****************************************************** -->
<?php

?>
<!-- <form name="form" action="Inv_c.php" method="post">
<table width="600" align="center">

<td align="center" width ="800" valign="top" colspan="2">
<h2>Creando Área de Captura</h2>
</td>
</tr>

<tr>
<td valign="top" align="right">
Cuantos Filas a crear:
</td>
<td valign="top" align="left">
<input type="text" name="num" />
</td>
</tr>

<tr>
<td valign="top" width="100" align="center" colspan="2">
<input type="button" value="Crear Fila" title="Crear Fila" onclick="validar();" />
</td>
</tr>
 -->


<TABLE BORDER="1" WIDTH="1200" CELLPADDING="6" CELLSPACING="6">

<?php echo $tabla_html;?>
<!-- TR>
	<TD WIDTH="500">Primera Parte </TD>
	<TD WIDTH="500"> Segunda Parte </TD>
	<TD WIDTH="500"> Tercera Parte </TD>
	<TD WIDTH="500"> Cuarta Parte </TD>
</TR> -->
<tr>
	<TD > <?echo $arreglo;?></TD>
	<TD > <?echo $num_mi_fila;?></TD>
	<TD > <?echo $creando_tabla_row?></TD>
	<TD > <?print_r($num_mi_fila);?></TD>
</TR>
</TABLE>

</form>





</body>
</html>
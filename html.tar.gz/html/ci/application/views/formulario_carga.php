<html>
<head>
<title>Formulario de Carga</title>
</head>
<body>

<?php form_open_multipart('upload/do_upload');?>
<input type="file" name="userfile" size="20" />
<br /><br />
<input type="submit" value="upload" />
<p><?php anchor('firma_c', 'Subir otro archivo!');?></p>
</form>
</body>
</html>
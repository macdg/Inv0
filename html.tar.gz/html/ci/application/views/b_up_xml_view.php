<?php
$this->load->helper('html','form');
echo validation_errors();
?>

<head>
<title>Pagina de Selección</title>
</head>
<body>
<center>

<?php
echo validation_errors();
echo br(2);
echo heading('Ingrese la Opción Deseada', 2);
echo br(2);
echo heading('Opciones de Lectura de XML:', 3);
echo br(1);
echo form_open_multipart('index.php/b_up_xml_controller1/validando_inicio');
?>

1.- Archivo XML con un Concepto.
<input type="checkbox" name="mi_check" value="1" <?php echo set_checkbox('mi_check', '1'); ?> />
<?php
echo br(2); ?>

2.- Archivo XML con más de un Concepto.
<input type="checkbox" name="mi_check" value="2" <?php echo set_checkbox('mi_check', '2'); ?> />
<?php  ?>


<?php
echo br(2);
echo form_submit('Aceptar', 'Aceptar').form_reset('Reset', 'Reset');
?>

<?php
$this->output->enable_profiler(TRUE);
?>

</center>
</body>
</html>

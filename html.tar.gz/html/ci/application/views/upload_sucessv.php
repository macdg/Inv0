<article class="contenido">
	<ul>
<?php error_reporting(E_ALL^E_NOTICE^E_WARNING);
foreach ($success as $item => $value) {
	echo '<li>'.$item.'-'.$value.'</li>';
}
?>
</ul>
<?php anchor('firma_c', 'Subir otro archivo!');?>
</article>

<!-- error_reporting(E_ALL ^ E_NOTICE ^E_WARNING); -->
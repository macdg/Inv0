<!DOCTYPE html>
<html>
<head>
	<title>Vista de Up XML</title>
</head>
<body>

	<hr>
	<br><br>
	<center>
	Elije el archivo XML a subir.
	<br><br><br>
	XML Seleccionado.
	<br>
	<form action="<?php echo 'b_contenido_xml_1_view'; ?>" method="post" enctype="multipart/form-data">
		Selecciona el archivo a Subir.
		<br><br><br>
		<input type="file" name="mi_archivo_1" id="m_archivo_1" size="20">
		<br>
		<input type="submit" value="Subir" name="submit">
		<br><br>
	</form>
</center>

<TABLE BORDER=1 WIDTH="700"> <!-- CELLPADDING="6" CELLSPACING="6" -->

<TR>
<TD WIDTH="600">Cantidad </TD>
<TD WIDTH="1400"> Concepto </TD>
<TD WIDTH="1400"> UUID </TD>
</TR>

</TABLE>
<?php
//foreach ($todos_archivos as $c_hay => $value) {
//	echo '<br>'."Key: ".$c_hay.' Valores: '.$value.'<br>';
//	$c_hay++;
?>
<TABLE BORDER=1 WIDTH="700"> <!-- CELLPADDING="10" CELLSPACING="2" COLSPAN=50 -->
<TR>
<TD WIDTH="300"><?php echo $cant;?></TD>
<TD WIDTH="400"><?php echo $descrip; ?></TD>
<TD WIDTH="400"><?php echo $uuid; ?></TD>
</TR>
</TABLE>

<?php //}   ?>

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

<!-- Esta tabla esta incluida con POO -->
<?php
// $instanciando=new D_new_controller1;
// $acceso_poo=$instanciando->index();
//$poo=$acceso_poo->datos_del_string;
?>
<!-- <TABLE BORDER="1" WIDTH="200" CELLPADDING="6" CELLSPACING="6">

<TR>
	<TD WIDTH="500">Primera Parte </TD>
	<TD WIDTH="500"> Segunda Parte </TD>
	<TD WIDTH="500"> Tercera Parte </TD>
	<TD WIDTH="500"> Cuarta Parte </TD>
</TR>
<TR>
	<TD > <?//echo $this->datos_del_string['i']=$encab_sock;?></TD>
	<TD > <?//echo print_r($string_fichero1);?></TD>
	<TD > <?//echo $this->$acceso_poo->$datos_del_string['k']=$string_fichero2;?></TD>
	<TD > <?//print_r($string_fichero3);?></TD>
</TR>
</TABLE>
 -->

<hr>

<?php //error_reporting(E_ALL^E_WARNING^E_NOTICE);?>
<!-- <h3>Mi Lista de Tareas</h3>

- Aqui empieza mi HTML - (Lo de arriba apartir de este mensaje proviene del controlador).
<br><br><br>
Esto es para imprimir mis "datos" (array) desde el controlador (Aquí hasta el momento no lo hace). -->

<?php

// foreach ($cadena as $k => $value) {
// 	echo 'Numero:'.$k.' Valor:'.$value;}

// print_r($cadena);

// echo '<br><br>';
// echo "<pre>";
// print_r(get_filenames('/root/CertificadosUnion/'));
// echo "</pre>";
//$c_hay = count($cadena);
// echo '<br>Lo que hay:'.$c_hay;
// echo '<br>$cadena:'.$cadena;

// foreach ($cadena as $c_hay => $value) {

// 	echo '<br>'."La Cadena:".$c_hay.' Valores:'.$value.'<br>';
// }

// foreach ($cadena as $col) {
// 	echo "<br>Cadena:".$cadena.' valores:'.$col;
// }
// echo '<br><br>';
// echo base_url();
// echo '<br><br>';
// echo uri_string();
// echo '<br>'.'<br>';
// echo current_url();
// echo '<br><br>';
// $cadena = get_filenames('/root/CertificadosUnion/');

//$this->load->view('d_new_view', $cadena, TRUE);

//$this->load->view('d_new_view', $cadena);

// $c_hay = count($cadena);
// echo '<br>Cantidad de archivos que se encuentran en la carpeta:'.$c_hay;

// $this->load->view('d_new_view', $c_hay);
// $this->load->view('d_new_view', $cadena);
?>


	<?php

echo "<br>";
?>
<br><br>

***************************************************************************************************************************************

<?php
//print_r($mi_archivo_1);
//var_dump($mi_archivo_1);
//echo '<br>'.'++++Esto es lo que contiene $mi_archivo_1: '.$mi_archivo_1.'+++++++<br>';
//echo '<br>';
//echo $_FILES['mi_archivo_1'];

//print_r($_FILES['mi_archivo_1']);
//var_dump($_FILES['mi_archivo_1']);


// $mi_archivo_1 = $this->input->post('mi_archivo_1');
// $this->load->view('d_new_viewA', $mi_archivo_1);
// $mi_archivo_2 = $this->input->post('mi_archivo_2');
// $this->load->view('d_new_viewA', $mi_archivo_2);
// echo $this->input->post('mi_archivo_1');
// echo $this->input->post('mi_archivo_2');

// $archivo_1 = $_POST['mi_archivo_1'];
// $archivo_2 = $_POST['mi_archivo_2'];
// $this->load->view('d_new_viewA', $archivo_1);
// $this->load->view('d_new_viewA', $archivo_2);

// echo '<br>'.$archivo_1.'<br>';
// echo '<br>'.$archivo_2.'<br>';

// $tratando_arch = fopen($mi_archivo_1, "r") or die("No puedo abrir el archivo!");
// echo fread($tratando_arch, filesize($mi_archivo_1));
// fclose($mi_archivo_1);
// echo '<br>'.$archivo_2.$_POST['mi_archivo_2'].'<br>';

// $tratando_arch = fopen($mi_archivo_2, "r") or die("No puedo abrir el archivo!");
// echo fread($tratando_arch, filesize($mi_archivo_2));
// fclose($mi_archivo_2);

?>
<br><br><br>
<?php
// $this->load->$encab_sock;
// $this->load->$string_fichero1;
// $this->load->$string_fichero2;
// $this->load->$string_fichero3;

?>

<!--     +++++++++++++++  Todo este Bloque COMENTADO
 <br><br><br>
-Aqui termina mi HTML-
<br>
<TABLE BORDER="1" WIDTH="200" CELLPADDING="6" CELLSPACING="6">

<TR>
	<TD WIDTH="500">Primera Parte </TD>
	<TD WIDTH="500"> Segunda Parte </TD>
	<TD WIDTH="500"> Tercera Parte </TD>
	<TD WIDTH="500"> Cuarta Parte </TD>
</TR>
<TR>
	<TD > <?//echo $encab_sock;?></TD>
	<TD > <?//echo $string_fichero1;?></TD>
	<TD > <?//echo $string_fichero2;?></TD>
	<TD > <?//echo $string_fichero3;?></TD>
</TR>
</TABLE>
<br><br>

Otros datos del archivo:   +++++++++++++ Linea Final de html comentado -->
<?//php echo '"'.$nom_archivo.'"';?>

<?php
//$info_carpeta = array(get_file_info('/root/CertificadosUnion1/archivo.php'));

//// foreach ($info_carpeta as $info_hay => $info_value) {
//// 	//echo '<br>'."La Cadena:".$c_hay.' Valores:'.$value.'<br>';
//// 	$info_hay++;
//// }
//print_r($info_carpeta);
?>
<!--  <TABLE BORDER=2 WIDTH="320">  CELLPADDING="10" CELLSPACING="2" COLSPAN=50
<TR> <TD WIDTH="100"><?php //echo $info_hay;?></TD> <TD WIDTH="210" > <?php //echo $info_value?></TD>
</TABLE>  -->
<?php
// echo '<br>';
// echo symbolic_permissions(fileperms('/root/CertificadosUnion1/archivo.php'));
// echo '<br>';
// echo octal_permissions(fileperms('/root/CertificadosUnion1/archivo.php'));
// echo '<br>';
echo '<br>';
//echo readfile("/root/CertificadosUnion1/archivo.php");
?>

</body>
</html>

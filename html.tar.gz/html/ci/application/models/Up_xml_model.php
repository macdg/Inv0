<?php

class Up_xml_model extends CI_Model {

 public function __construct()
 {
 parent::__construct();
$this->load->model('Up_xml_model','up_xml_model');

 }

public function concepto_data_insert($id_uuid, $cantidad, $unidad, $no_ident, $descrip, $val_unit) {

$concepto_datos=array(
	'id_uuid' => $id_uuid,
	'cantidad' => $cantidad,
	'unidad' => $unidad,
	'no_ident' => $no_ident,
	'descrip' => $descrip,
	'val_unit' => $val_unit
 );

$this->db->insert('concepto',$concepto_datos);


} //Fin de concepto_data_insert();


public function proveedor_data_insert($rfc, $rfc_nom, $calle, $no_ext, $no_int, $colonia, $referen, $mun, $estado, $pais, $cp) {

$proveedor_datos=array(
'rfc' => 	$rfc,
'rfc_nom' =>	$rfc_nom,
'calle' =>	$calle,
'no_ext' =>	$no_ext,
'no_int' =>	$no_int,
'colonia' =>	$colonia,
'referen' =>	$referen,
'mun' =>	$mun,
'estado' =>	$estado,
'pais' =>	$pais,
'cp' =>	$cp
	);

$this->db->insert('proveedor',$proveedor_datos);


}  //Fin de proveedor_data_insert();


public function factura_data_insert($rfc, $rfc_nom, $fecha, $subtotal, $moneda, $total) {

$factura_datos=array(
'rfc' => 	$rfc,
'rfc_nom' =>	$rfc_nom,
'fecha' => $fecha,
'subtotal' => $subtotal,
'moneda' => $moneda,
'total' => $total
	);

$this->db->insert('factura',$factura_datos);


}  //Fin de factura_data_insert();


public function productos_data_insert($cantidad, $unidad, $modelo, $descripcion, $valorunitario, $fecha_ingreso, $noserie, $nopieza) {

$datos=array(
'cantidad' => $cantidad,
'unidad' =>	$unidad,
'modelo' => $modelo,
'descripcion' => $descripcion,
'valorunitario' => $valorunitario,
'fecha_ingreso' => $fecha_ingreso,
'noserie' => $noserie,
'nopieza' => $nopieza
	);

$this->db->insert('productos',$datos);

$this->load->view('up_xml_view1');

}




}
<?php
//if (!defined('BASEPATH') OR exit('No direct script access allowed')) {;
// }

class Up_xml_controller extends CI_Controller {

//private $datos_del_string=array();

	public function __construct() {
		parent::__construct();
		$this->load->helper('file');
$this->load->helper('form','url');
		$this->load->helper('directory');

	}

	public function index() {
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);


		echo '<br>';
		echo '--------------------'.'<br>';
		

		// MANEJANDO LOS ARCHIVOS
$ruta_archivo = '/root/Documentos/rep_xml/';
echo '<br>'.'<br>'.'<br>';
print_r($_FILES['mi_archivo_1']);
echo '<br>'.'<br>'.'<br>';
var_dump($_FILES['mi_archivo_1']);

$mi_archivo_1=$_FILES['mi_archivo_1'];
$tip_arch=$mi_archivo_1['name'];
echo 'El nombre del archivo es:'.$tip_arch;
echo '<br>'.'<br>';

$val_ext=substr($tip_arch,-4);
echo '$val_ext: '.$val_ext;





if (is_uploaded_file($_FILES['mi_archivo_1']['tmp_name']))
{
 $nombreDirectorio = "/var/www/html/ci/uploads/";
 $nombreFichero = $_FILES['mi_archivo_1']['name'];
 
$nombreCompleto = $nombreDirectorio . $nombreFichero;
 


 	if (file_exists($nombreDirectorio.$nombreFichero)) {
			echo '<br>'."El archivo: ".$nombreFichero.',ya existe. Seleccione otro archivo.';
		//$this->load->view('up_x');
			$salida='up_xml_controller/index';
//		return ($this->load->view('up_xml_view'));
		} 

			move_uploaded_file($_FILES['mi_archivo_1']['tmp_name'], $nombreDirectorio.$nombreFichero);
 
 }
 
else
 print ("No se ha podido subir el fichero");





// foreach ($todos_archivos as $key => $value) {
//  echo '<br>Todos los archivos: '.$todos_archivos.'Key: '.$key.'Valor: '.$value;
// }

// //Todos los archivos: ArrayKey: 0Valor: NEO0303288Z1FB8410.xml


// echo "<br><hr/>";

// print_r($todos_archivos['0']);
// echo '<br>';
// print_r($todos_archivos['1']);
// echo "<br><hr/>";



echo '<br>Este es el contenido del archivo subido';
echo "<br><hr/>";
echo '<br>';
$this->load->helper('xml2array');
$contents = xml2array(file_get_contents($nombreDirectorio.$nombreFichero));
echo 'Contenido:'. print_r($contents,1);
echo '<br>';
// print_r($todos_archivos['$key']);
// echo '<br>';
// $contents = file_get_contents($todos_archivos['$key']);
// echo $contents;
// echo '<br>';
echo "<br><hr/>";


// for ($i = 0; $i < count($todos_archivos); $i++)
// {
// echo $todos_archivos[$i];
// 	echo "<br>";

// $this->load->view('xml2array', $contents);
// $contents= file_get_contents($ruta_archivo.$todos_archivos[$i]);
// $result = xml2array($contents);
// print_r($result);
// echo "<br>";

// // foreach ($result as $key => $value) {
// // echo '<br>###: '.$result.'Key: '.$key.'Valor: '.$value;
// // echo "<hr>";
// // }
// // echo $contents;
// // var_dump($contents);
// // print_r($contents);


// }


// $this->load->view('xml2array', $contents);
// $contents= file_get_contents('/var/www/html/ci/uploads/NEO0303288Z1FB8410.xml');
// $result = xml2array($contents);
// print_r($result);
// echo "<br><br><br><br>";


//****************************************

$contents= file_get_contents($nombreDirectorio.$tip_arch);
$result = xml2array($contents,1,'attribute');
// print_r($result);

$result2 = $result;
$result2['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'] = 
array($result2['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);

// print_r($result['cfdi:Comprobante']['cfdi:Conceptos']);
// print_r($result2['cfdi:Comprobante']['cfdi:Conceptos']);
echo "<br>";
$result3 = $result;
$result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital'] = 
array($result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']);


// $contents= file_get_contents('/var/www/html/ci/uploads/NEO0303288Z1FB8410.xml');
// $result = xml2array($contents,1,'attribute');
// print_r($result['cfdi:Comprobante']['cfdi:Conceptos']);


foreach (($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']) as $key => $value) {
	echo '<br>###Nivel1 Esto es lo que tiene $result: '.($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']).' $key: '.$key.' $value: '.$value.' ###';

if ($key=='cantidad')
	$cant=$value;
if ($key=='descripcion')
$descrip=$value;

}

//$d_uuid=$result3['cfdi:Comprobante']['cfdi:Complemento']['cfdi:TimbreFiscalDigital']['attr'];
$result3 = $result;
$result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital'] = 
array($result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']);

foreach ($result['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr'] as $key => $value) {
	echo '<br>%%%Nivel2 Esto es lo que tiene $result: '.$result['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr'].' $key: '.$key.' $value: '.$value.' %%%';

if ($key=='UUID')
	$uuid=$value;


}
echo "<br>";
// print_r($result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr']);



//CASO DE MAS PRODUCTOS DENTRO DE LA FACTURA.
echo '<br>@@@@@@  UUID:= '.$uuid.'  @@@@@@<br>';

$key_search='attr';
$si_existe_key=array_key_exists ( $key_search , $result['fdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
echo "<br><br>$si_existe_key: ".$si_existe_key;

echo '<br>@@@@@@@@@@@@<br>';
$nivel3=$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'];
print_r(array_keys($nivel3));
echo '<br><br>';
						
//print_r($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
if ($si_existe_key==NULL || $si_existe_key==FALSE) {


//*************************************
	$cont=count($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']);
echo '<br><br>$cont: '.$cont;
 foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'] as $key => $value) {
	echo '<br>@@@Nivel3 Esto es lo que tiene $result: '.$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'].'$key: '.$key.' @@@';

echo '<br><br>'.$key.'<br><br>'.$value;
//*************************************
		
//Para sacar los elementos de [cfdi:Parte]=[0],[1],[2],[3],[4];
		$elem_Parte=array($key);
 	echo	'elem: '.var_dump($elem_Parte);

// if ($key=='cantidad')
// 	$cant=$value;
// if ($key=='descripcion')
// $descrip=$value;
 																											

 }

 	foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['0']['attr'] as $key => $value) {
 		echo '<br><br>attrKEY:= '.$key.'  attrVALUE:= '.$value;
 	}
echo "<br><br>";
foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['0']['cfdi:Parte'] as $key => $value) {
 		echo '<br><br>attrKEY:= '.$key.'  attrVALUE:= '.$value;
 	$val_parte=count($key);
 	}
for($i=0; $i<=$val_parte; $i++){
foreach ($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'][$i]['cfdi:Parte']['attr'][$i][$i] as $val_parte => $value) {
 		echo '<br><br>ParteKEY:= '.$val_parte.'  ParteVALUE:= '.$value;
 	// $val_parte=count($key);
 				}	
 	}


// for ($i=0; $i<$cont; $i++){
// $nivel3=$result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto'][$i];

//echo '<br><br>$nivel3= '.print_r($nivel3);
//echo '<br><br>¬|¬|arraykeys:= '.array_keys($nivel3[$i]);
                          
//print_r( array_keys($nivel3));
//var_dump($nivel3);


if ($key=='cantidad')
	$cant=$value;
if ($key=='descripcion')
$descrip=$value;



                          //}
// $modo=next($nivel3);
// echo '<br><br>$nivel3NEXT0= '.$modo;
// echo '<br><br>¬|¬|arraykeys:= '.array_keys($result);
// $modo1=next($modo);
// echo '<br><br>$nivel3NEXT1= '.$modo1;
// $modo2=next($modo1);
// echo '<br><br>$nivel3NEXT2= '.$modo2;
// $modo3=next($modo2);
// echo '<br><br>$nivel3NEXT3= '.$modo3;
echo '<br><br>';
print_r( array_keys($nivel3));

}







// $contador=count($result3['cfdi:Comprobante']['cfdi:Complemento']['tfd:TimbreFiscalDigital']['attr']);
// echo '<br>Contador:'.$contador;


// $elem_arreglo="['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']";

// $todos_los_valores=array_values($result3['cfdi:Comprobante']['cfdi:Complemento']['cfdi:TimbreFiscalDigital']['attr']);

// print_r($todos_los_valores);

// var_dump($todos_los_valores1);
// var_dump($todos_los_valores);
// print_r($todos_los_valores);
// print_r($todos_los_valores1);

//echo "<br>$cant:".$cant.'$descrip:'.$descrip;

// $contador=count($result['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']);
// echo '<br>Contador:'.$contador;
// $elem_arreglo="['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['attr']";
 
$array            = array();
$array['cant']    = $cant;
$array['descrip'] = $descrip;
$array['uuid']    = $uuid;


//**************************************



//echo ($ruta_archivo.$todos_archivos['$key']);
//$contents = file_get_contents($ruta_archivo.$nom_archivo);
// echo $contents;
// var_dump($contents);
// print_r($contents);

// $contents = file_get_contents('sample.xml');//Or however you what it
// $result = xml2array($contents);
// print_r($result);


// <?php require(”xml2array.php”);
// $fichero = file_get_contents(’fichero.xml’); ?>
<?php// $array = xml2array($fichero); ?>

<?php








$this->load->view('up_xml_view', $array);




	







		echo '<br>';
		// print_r($file_information);
		// echo $file_information;
		echo '<br>';
		
		$this->output->enable_profiler(TRUE);

	}









}


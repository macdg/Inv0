<?php
// if (!defined('BASEPATH') OR exit('No direct script access allowed')) {;
// }

class Inv_c extends CI_Controller {

	private $datos_del_string     = array();
	private $creando_tabla_row    = array();
	private $creando_tabla_column = array();

	//public function __construct() {
	// 	parent::__construct();
	// 	// $this->load->helper('file');

	// 	// $this->load->helper('directory');

	// }
	//$array['string_fichero3'] = $string_fichero3;
	public function index() {

		$arreglo                     = 'Hola';
		$datos_del_string['arreglo'] = $arreglo;

		$tabla_html = '
		<TR>
	<TD WIDTH="500">Primera Parte </TD>
	<TD WIDTH="500"> Segunda Parte </TD>
	<TD WIDTH="500"> Tercera Parte </TD>
	<TD WIDTH="500"> Cuarta Parte </TD>
</TR>';
		$datos_del_string['tabla_html'] = $tabla_html;

		$creando_tabla_row['num_mi_fila1'] = $_POST['num_mi_fila1'];
		// $num_mi_fila                      = $this->input->post('num_mi_fila');
		// $creando_tabla_row['num_mi_fila'] = $_POST['num_mi_fila'];
		print_r($_POST['num_mi_fila1']);
		echo $_POST['num_mi_fila1'];
		var_dump($_POST);
		var_dump($_POST['num_mi_fila1']);

		//$datos_del_string['mi'] = $_POST['mi_fila'];
		//$datos_del_string['num_mi_fila'] = $num_mi_fila;

		// if ($tabla_tam) {
		// 	# code...
		// }

		$this->load->view('inv_v', $datos_del_string, $creando_tabla_row);
	}

}

// $mi_archivo_1 = $this->input->post('mi_archivo_1');
// $this->load->view('d_new_viewA', $mi_archivo_1);
// $mi_archivo_2 = $this->input->post('mi_archivo_2');
// $this->load->view('d_new_viewA', $mi_archivo_2);
// echo $this->input->post('mi_archivo_1');
// echo $this->input->post('mi_archivo_2');

// $archivo_1 = $_POST['mi_archivo_1'];
// $archivo_2 = $_POST['mi_archivo_2'];
// $this->load->view('d_new_viewA', $archivo_1);
// $this->load->view('d_new_viewA', $archivo_2);

// echo '<br>'.$archivo_1.'<br>';
// echo '<br>'.$archivo_2.'<br>';